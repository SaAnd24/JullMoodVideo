package com.jullmood.video.scan

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import com.jullmood.video.data.Video
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/**
 * Recorre la carpeta elegida con el selector nativo (SAF) y todas sus subcarpetas.
 * Es INCREMENTAL: si un archivo conserva tamaño y fecha de modificación se reutilizan sus datos
 * (duración, resolución) y no se vuelve a abrir. Solo se leen los archivos nuevos o cambiados.
 * Nunca lanza por un archivo o subcarpeta ilegible: los omite. Solo la carpeta raíz inaccesible lanza SecurityException.
 */
object VideoScanner {

    private val VIDEO_EXT = setOf(
        "mp4", "mkv", "webm", "avi", "mov", "m4v", "3gp", "ts", "mpg", "mpeg", "wmv", "flv"
    )

    private class Entry(val docId: String, val name: String, val size: Long, val modified: Long)

    /** Nombre legible de la carpeta a partir del URI del árbol (p. ej. "Movies/Series"). */
    fun label(tree: Uri): String = runCatching {
        DocumentsContract.getTreeDocumentId(tree).substringAfter(':', "").trim('/')
    }.getOrDefault("").ifEmpty { "Almacenamiento interno" }

    /** [onProgress] recibe (hechos, total). Durante el listado total = -1. */
    suspend fun scan(
        ctx: Context, tree: Uri, known: Map<String, Video>, onProgress: (Int, Int) -> Unit
    ): List<Video> {
        val entries = list(ctx, tree, onProgress)
        val out = ArrayList<Video>(entries.size)
        for ((i, e) in entries.withIndex()) {
            currentCoroutineContext().ensureActive()
            val uri = DocumentsContract.buildDocumentUriUsingTree(tree, e.docId)
            val old = known[e.docId]
            out += if (old != null && old.sizeBytes == e.size && old.modifiedMs == e.modified) {
                old.copy(uri = uri.toString(), name = e.name)
            } else {
                probe(ctx, e, uri)
            }
            if ((i + 1) % 10 == 0 || i + 1 == entries.size) onProgress(i + 1, entries.size)
        }
        return out
    }

    private suspend fun list(ctx: Context, tree: Uri, onProgress: (Int, Int) -> Unit): List<Entry> {
        val found = ArrayList<Entry>()
        val pending = ArrayDeque<String>().apply { add(DocumentsContract.getTreeDocumentId(tree)) }
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        var first = true
        while (pending.isNotEmpty()) {
            currentCoroutineContext().ensureActive()
            val dir = pending.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dir)
            try {
                ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: continue
                        val mime = c.getString(2).orEmpty()
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            if (!name.startsWith(".")) pending.add(id)   // ignora .thumbnails, .trash…
                        } else if (!name.startsWith(".") &&
                            (mime.startsWith("video/") || name.substringAfterLast('.', "").lowercase() in VIDEO_EXT)
                        ) {
                            found += Entry(id, name, c.getLong(3), c.getLong(4))
                            if (found.size % 50 == 0) onProgress(found.size, -1)
                        }
                    }
                }
            } catch (e: SecurityException) {
                if (first) throw e          // sin acceso a la carpeta raíz: lo gestiona el llamador
            } catch (_: Exception) {
                // una subcarpeta ilegible no detiene el análisis
            }
            first = false
        }
        onProgress(found.size, -1)
        return found
    }

    /** Lee duración y resolución. Si el archivo no se puede abrir, el video se indexa igual con datos en 0. */
    private fun probe(ctx: Context, e: Entry, uri: Uri): Video {
        var duration = 0L
        var w = 0
        var h = 0
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }   // el video vertical se guarda girado
        } catch (_: Exception) {
        } finally {
            runCatching { r.release() }
        }
        return Video(
            key = e.docId, uri = uri.toString(), name = e.name, folder = folderOf(e.docId),
            sizeBytes = e.size, modifiedMs = e.modified, durationMs = duration, width = w, height = h
        )
    }

    /** "primary:Movies/Series/a.mp4" -> "Movies/Series" (carpeta relativa al volumen). */
    private fun folderOf(docId: String): String =
        docId.substringAfter(':', docId).substringBeforeLast('/', "")
}
