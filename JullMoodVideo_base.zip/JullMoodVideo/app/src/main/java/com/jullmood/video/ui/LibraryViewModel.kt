package com.jullmood.video.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullmood.video.data.Video
import com.jullmood.video.data.VideoRepository
import com.jullmood.video.scan.VideoScanner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Estado de la biblioteca. Fase 0: carpeta, escaneo, lista, favoritos, progreso y video en reproducción. */
class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("video", Context.MODE_PRIVATE)
    private val repo = VideoRepository(app)
    private var scanJob: Job? = null

    var folder by mutableStateOf<Uri?>(prefs.getString("folder", null)?.let { Uri.parse(it) }); private set
    var videos by mutableStateOf<List<Video>>(emptyList()); private set
    var scanning by mutableStateOf(false); private set
    var scanDone by mutableIntStateOf(0); private set
    var scanTotal by mutableIntStateOf(-1); private set
    var scanError by mutableStateOf<String?>(null); private set
    var playing by mutableStateOf<Video?>(null); private set

    init {
        viewModelScope.launch {
            // Se muestra al instante lo que ya hay en la base de datos; luego se reescanea (incremental).
            videos = withContext(Dispatchers.IO) { runCatching { repo.all() }.getOrDefault(emptyList()) }
            if (folder != null) scan()
        }
    }

    /** Guarda la carpeta elegida con el selector nativo (con permiso persistente) y reescanea. */
    fun chooseFolder(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        folder = uri
        prefs.edit().putString("folder", uri.toString()).apply()
        scan()
    }

    fun scan() {
        val tree = folder ?: return
        if (scanning) return
        val ctx = getApplication<Application>()
        scanJob = viewModelScope.launch {
            scanning = true
            scanError = null
            scanDone = 0
            scanTotal = -1
            try {
                val known = withContext(Dispatchers.IO) { repo.all() }.associateBy { it.key }
                val found = withContext(Dispatchers.IO) {
                    VideoScanner.scan(ctx, tree, known) { done, total -> scanDone = done; scanTotal = total }
                }
                if (found.isEmpty() && known.isNotEmpty()) {
                    // Estabilidad: un resultado vacío con biblioteca previa suele ser un fallo de acceso, no que se borrara todo.
                    scanError = "No se encontró ningún video. Si no es lo esperado, vuelve a elegir la carpeta."
                } else {
                    withContext(Dispatchers.IO) { repo.applyScan(found, System.currentTimeMillis()) }
                    videos = withContext(Dispatchers.IO) { repo.all() }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                scanError = "Sin acceso a la carpeta. Vuelve a elegirla."
            } catch (e: Exception) {
                scanError = "Error al analizar: ${e.javaClass.simpleName}"
            } finally {
                scanning = false
            }
        }
    }

    fun play(v: Video) { playing = v }

    /** Guardado periódico mientras suena. */
    fun saveProgress(v: Video, positionMs: Long, durationMs: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { repo.saveProgress(v.key, positionMs, durationMs) } }
    }

    /** Cierra el reproductor: guarda y refresca la lista en ese orden (así "Continuar viendo" ya viene al día). */
    fun closePlayer(v: Video, positionMs: Long, durationMs: Long) {
        playing = null
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { repo.saveProgress(v.key, positionMs, durationMs) }
                runCatching { repo.all() }.getOrNull()
            }
            if (list != null) videos = list
        }
    }

    fun toggleFavorite(v: Video) {
        val now = !v.favorite
        videos = videos.map { if (it.key == v.key) it.copy(favorite = now) else it }
        viewModelScope.launch(Dispatchers.IO) { runCatching { repo.setFavorite(v.key, now) } }
    }
}
