package com.jullmood.video.data

/**
 * Un archivo de video de la biblioteca.
 *
 * [key] es la IDENTIDAD ESTABLE: el id de documento del selector de archivos (p. ej. "primary:Movies/a.mp4").
 * Favoritos, progreso y correcciones manuales se guardan por esta clave, así que sobreviven a reescaneos,
 * a cambiar de carpeta raíz y a reinstalar. Si el archivo se mueve de carpeta, la clave cambia
 * (la reasociación por huella tamaño+duración llegará con el motor de identificación).
 */
data class Video(
    val key: String,
    val uri: String,
    val name: String,
    val folder: String,
    val sizeBytes: Long,
    val modifiedMs: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val addedAt: Long = 0L,
    val positionMs: Long = 0L,
    val watched: Boolean = false,
    val lastPlayedAt: Long = 0L,
    val favorite: Boolean = false
) {
    /** Título para mostrar: nombre sin extensión y sin guiones bajos. (La limpieza real llegará con la identificación.) */
    val title: String
        get() = name.substringBeforeLast('.').replace('_', ' ').trim().ifEmpty { name }

    val progress: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}
