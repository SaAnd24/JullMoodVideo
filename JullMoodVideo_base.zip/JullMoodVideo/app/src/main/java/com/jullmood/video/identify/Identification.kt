package com.jullmood.video.identify

import com.jullmood.video.data.Video

/** Categorías principales. Las subdivisiones van en [Identification.path] (p. ej. Gameplays > Resident Evil > Markiplier). */
enum class Category(val label: String) {
    VIDEOJUEGOS("Videojuegos"),
    PELICULAS("Películas"),
    SERIES("Series"),
    MEMES("Memes"),
    SHORTS("TikTok / Shorts"),
    YOUTUBE("YouTube"),
    OTROS("Otros"),
    SIN_CLASIFICAR("Sin clasificar")
}

enum class IdSource { AUTO, MANUAL }

/**
 * Resultado de identificar un video.
 * [confidence] 0..1. Regla de producto: por debajo de [MIN_CONFIDENCE] el video queda en SIN_CLASIFICAR
 * (puede llevar una sugerencia, pero no se aplica sola). Una identificación MANUAL siempre gana.
 */
data class Identification(
    val category: Category,
    val path: List<String> = emptyList(),
    val confidence: Float = 0f,
    val source: IdSource = IdSource.AUTO,
    val evidence: List<String> = emptyList()
) {
    companion object {
        const val MIN_CONFIDENCE = 0.7f
    }
}

/**
 * Motor de identificación por capas (nombre, carpeta, archivos relacionados, datos locales, aproximada, externa).
 * Debe ser una función pura y rápida, sin red ni E/S pesada, para poder probarla en JVM.
 */
interface Identifier {
    fun identify(video: Video): Identification
}

/** Marcador de posición de la fase 0: todo queda en Sin clasificar hasta que exista el motor real. */
object PendingIdentifier : Identifier {
    override fun identify(video: Video) = Identification(Category.SIN_CLASIFICAR)
}
