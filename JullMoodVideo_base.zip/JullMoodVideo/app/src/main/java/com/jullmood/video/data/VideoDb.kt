package com.jullmood.video.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Base de datos local (SQLite nativo, sin dependencias). Esquema v1.
 *
 * Reglas de diseño:
 *  - `video` es un ÍNDICE regenerable a partir de la carpeta. Se puede borrar sin perder nada del usuario.
 *  - Todo lo que es del usuario (progress, favorite, override_manual, collection*) va en tablas aparte,
 *    ligadas por `vkey` sin clave foránea: reescanear o desaparecer un archivo nunca borra esos datos.
 *  - identity_auto es lo que calcula el motor (recalculable); override_manual es lo que corrige el usuario y SIEMPRE gana.
 *  - work guarda metadata externa en caché para que la biblioteca funcione offline.
 * Las tablas identity_auto, override_manual, work y collection* están listas pero aún sin uso (fases siguientes).
 */
class VideoDb(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "videos.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE video (
                vkey TEXT PRIMARY KEY,
                uri TEXT NOT NULL,
                name TEXT NOT NULL,
                folder TEXT NOT NULL,
                size INTEGER NOT NULL DEFAULT 0,
                modified INTEGER NOT NULL DEFAULT 0,
                duration_ms INTEGER NOT NULL DEFAULT 0,
                width INTEGER NOT NULL DEFAULT 0,
                height INTEGER NOT NULL DEFAULT 0,
                added_at INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL(
            """CREATE TABLE progress (
                vkey TEXT PRIMARY KEY,
                position_ms INTEGER NOT NULL DEFAULT 0,
                duration_ms INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL DEFAULT 0,
                watched INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL("CREATE TABLE favorite (vkey TEXT PRIMARY KEY, added_at INTEGER NOT NULL DEFAULT 0)")
        db.execSQL(
            """CREATE TABLE identity_auto (
                vkey TEXT PRIMARY KEY,
                category TEXT NOT NULL,
                path TEXT NOT NULL DEFAULT '',
                confidence REAL NOT NULL DEFAULT 0,
                evidence TEXT NOT NULL DEFAULT '',
                computed_at INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL(
            """CREATE TABLE override_manual (
                vkey TEXT PRIMARY KEY,
                category TEXT NOT NULL,
                path TEXT NOT NULL DEFAULT '',
                title TEXT NOT NULL DEFAULT '',
                updated_at INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL(
            """CREATE TABLE work (
                provider TEXT NOT NULL,
                external_id TEXT NOT NULL,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                year INTEGER NOT NULL DEFAULT 0,
                poster_file TEXT NOT NULL DEFAULT '',
                json TEXT NOT NULL DEFAULT '',
                fetched_at INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (provider, external_id)
            )"""
        )
        db.execSQL(
            """CREATE TABLE collection (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                created_at INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL(
            """CREATE TABLE collection_item (
                collection_id INTEGER NOT NULL,
                vkey TEXT NOT NULL,
                position INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (collection_id, vkey)
            )"""
        )
        db.execSQL("CREATE INDEX idx_video_folder ON video(folder)")
    }

    // Migraciones: una rama por versión, nunca borrar tablas del usuario.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    }
}
