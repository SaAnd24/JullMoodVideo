package com.jullmood.video.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase

/** Acceso a la base de datos. Todas las funciones son síncronas: llamarlas desde Dispatchers.IO. */
class VideoRepository(ctx: Context) {

    private val helper = VideoDb(ctx)

    /** Videos con su progreso y favorito, ordenados por nombre. */
    fun all(): List<Video> {
        val out = ArrayList<Video>()
        val sql = """
            SELECT v.vkey, v.uri, v.name, v.folder, v.size, v.modified, v.duration_ms, v.width, v.height, v.added_at,
                   COALESCE(p.position_ms, 0), COALESCE(p.watched, 0), p.updated_at,
                   CASE WHEN f.vkey IS NULL THEN 0 ELSE 1 END
            FROM video v
            LEFT JOIN progress p ON p.vkey = v.vkey
            LEFT JOIN favorite f ON f.vkey = v.vkey
            ORDER BY v.name COLLATE NOCASE
        """.trimIndent()
        helper.readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) {
                out += Video(
                    key = c.getString(0), uri = c.getString(1), name = c.getString(2), folder = c.getString(3),
                    sizeBytes = c.getLong(4), modifiedMs = c.getLong(5), durationMs = c.getLong(6),
                    width = c.getInt(7), height = c.getInt(8), addedAt = c.getLong(9),
                    positionMs = c.getLong(10), watched = c.getInt(11) == 1,
                    lastPlayedAt = if (c.isNull(12)) 0L else c.getLong(12),
                    favorite = c.getInt(13) == 1
                )
            }
        }
        return out
    }

    /**
     * Sincroniza el índice `video` con el resultado de un escaneo: inserta lo nuevo, actualiza lo existente
     * y elimina lo que ya no está. NO toca progress, favorite ni ningún dato del usuario.
     * Todo en una transacción: si algo falla, el índice queda como estaba.
     */
    fun applyScan(found: List<Video>, now: Long) {
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val existing = HashSet<String>()
            db.rawQuery("SELECT vkey FROM video", null).use { c -> while (c.moveToNext()) existing += c.getString(0) }
            val seen = HashSet<String>(found.size * 2)
            for (v in found) {
                seen += v.key
                val cv = ContentValues().apply {
                    put("uri", v.uri); put("name", v.name); put("folder", v.folder)
                    put("size", v.sizeBytes); put("modified", v.modifiedMs)
                    put("duration_ms", v.durationMs); put("width", v.width); put("height", v.height)
                }
                if (v.key in existing) {
                    db.update("video", cv, "vkey = ?", arrayOf(v.key))
                } else {
                    cv.put("vkey", v.key)
                    // Fecha de "añadido": la del archivo si existe (así la primera pasada no pone todo igual).
                    cv.put("added_at", if (v.modifiedMs > 0) v.modifiedMs else now)
                    db.insert("video", null, cv)
                }
            }
            for (k in existing) if (k !in seen) db.delete("video", "vkey = ?", arrayOf(k))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Guarda la posición; se marca como visto al llegar al 90 %. */
    fun saveProgress(key: String, positionMs: Long, durationMs: Long) {
        val watched = durationMs > 0 && positionMs >= durationMs * 9 / 10
        val cv = ContentValues().apply {
            put("vkey", key); put("position_ms", positionMs); put("duration_ms", durationMs)
            put("updated_at", System.currentTimeMillis()); put("watched", if (watched) 1 else 0)
        }
        helper.writableDatabase.insertWithOnConflict("progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun setFavorite(key: String, favorite: Boolean) {
        val db = helper.writableDatabase
        if (favorite) {
            val cv = ContentValues().apply { put("vkey", key); put("added_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("favorite", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        } else {
            db.delete("favorite", "vkey = ?", arrayOf(key))
        }
    }
}
