# Arquitectura de JullMood Video

Prioridades: estabilidad > rendimiento > simplicidad > diseño > funcionalidades adicionales.
Sin IA, servidores, servicios en segundo plano ni dependencias pesadas.

## Decisiones respecto a JullMood Music
| Tema | Music | Video | Motivo |
|---|---|---|---|
| Persistencia | SharedPreferences + JSON | SQLite nativo (sin librerías) | El progreso se guarda cada pocos segundos para miles de archivos |
| Biblioteca | En memoria, reescaneo en cada arranque | Índice persistido + escaneo incremental | Leer la duración de cada video es caro |
| Identidad | `song.id` (MediaStore o hash) | `vkey` = id de documento SAF | Favoritos, progreso y correcciones sobreviven a reescaneos |
| Reproducción | Servicio en primer plano + MediaSession | ExoPlayer en la pantalla, sin servicio | Sin procesos en segundo plano |
| Permisos | READ_MEDIA_AUDIO, notificaciones, foreground | Ninguno (SAF) | Menos superficie de fallos |

## Datos (esquema v1, `VideoDb`)
- `video`: índice regenerable (ruta relativa, tamaño, fecha, duración, resolución).
- `progress`, `favorite`, `collection`, `collection_item`: datos del usuario, ligados por `vkey` **sin clave foránea**: reescanear o perder un archivo nunca los borra.
- `identity_auto` (calculado, recalculable) y `override_manual` (corrección del usuario, **siempre gana**).
- `work`: metadata externa en caché para funcionar offline.

## Identificación por capas (contrato en `identify/`)
1. Nombre del archivo · 2. Carpeta/ruta · 3. Archivos relacionados · 4. Duración y datos locales ·
5. Búsqueda aproximada · 6. Metadata externa · 7. Corrección manual.
Cada capa aporta evidencia con peso; si la confianza es menor que `Identification.MIN_CONFIDENCE` el video queda en **Sin clasificar**
(con sugerencia opcional, nunca aplicada sola).

## Categorías virtuales
Cada video tiene atributos (categoría, subcategorías, franquicia, creador, temporada/episodio, año). Las vistas son consultas sobre esos
atributos, no copias: un mismo archivo aparece en Videojuegos → Gameplays → Resident Evil → Markiplier y en Películas → Resident Evil.

## Metadata externa (contrato en `metadata/`)
Interfaz `MetadataProvider` + registro de proveedores por tipo. Solo saldría título limpio y año. Resultado guardado en `work` y en disco.

## Fases
0. **Esqueleto, escaneo, miniaturas, reproductor, progreso y favoritos (esta base).**
1. Motor de identificación (Kotlin puro, con pruebas JVM) + "Corregir identificación" + reglas por carpeta.
2. Vistas virtuales y colecciones; Home por categorías y fila "Por revisar".
3. Metadata externa opt-in (primer proveedor), posters en disco.
4. Pulido: orden/filtros, búsqueda, ajustes y temas portados de Music.
