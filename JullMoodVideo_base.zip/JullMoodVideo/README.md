# JullMood Video — base del proyecto (fase 0)

Reproductor y biblioteca de videos 100 % local. Hereda el stack y el diseño de JullMood Music
(Kotlin + Compose + Media3, mismas versiones de Gradle/AGP/Kotlin) sin copiar nada específico de música.

## Cómo compilar
- **Android Studio:** abrir esta carpeta y ejecutar `app`. (Si no hay `gradlew`, usar Gradle 8.2: Studio lo descarga solo.)
- **GitHub Actions:** subir el contenido de esta carpeta (o el .zip); `.github/workflows/build.yml` genera `JullMoodVideo-debug.apk`.
- Requisitos: JDK 17, Android SDK 34. Paquete/applicationId: `com.jullmood.video` (convive con JullMood Music).

## Qué hace esta base
1. Primer inicio: eliges la carpeta de videos con el selector nativo (SAF). **Sin permisos de almacenamiento.**
2. Escanea la carpeta y subcarpetas (incremental: solo lee archivos nuevos o cambiados) y guarda un índice en SQLite.
3. Miniaturas en memoria + disco, generadas bajo demanda (máx. 2 a la vez).
4. Home tipo Netflix: Continuar viendo, Añadido recientemente, Favoritos y la lista completa (por ahora todo en "Sin clasificar").
5. Reproductor ExoPlayer a pantalla completa: reanuda, guarda progreso cada 5 s, marca como visto al 90 %.
6. Favoritos. Pantalla de error legible si la app se cierra por un fallo (heredada de Music).

## Qué NO hace todavía (a propósito)
Motor de identificación, categorías virtuales, colecciones, corrección manual y metadata externa.
Sus **contratos y tablas ya existen** (`identify/`, `metadata/`, `data/VideoDb.kt`) para que se añadan sin migraciones dolorosas.
Ver `docs/ARCHITECTURE.md`.

## Estructura
```
app/src/main/java/com/jullmood/video/
  CrashApp.kt, MainActivity.kt
  data/      Video, VideoDb (esquema v1), VideoRepository
  scan/      VideoScanner (SAF, incremental)
  thumbs/    ThumbCache (memoria + disco)
  identify/  contrato Identifier + Category (sin lógica)
  metadata/  contrato MetadataProvider (sin proveedores)
  player/    PlayerScreen
  ui/        Theme, LibraryViewModel, Screens
```
