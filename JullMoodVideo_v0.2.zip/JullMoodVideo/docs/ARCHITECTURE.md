# Arquitectura de JullMood Video

Prioridades: estabilidad > rendimiento > simplicidad > diseño > funcionalidades adicionales.
Sin IA, servidores, servicios en segundo plano ni dependencias pesadas.

## Decisiones respecto a JullMood Music
| Tema | Music | Video | Motivo |
|---|---|---|---|
| Persistencia | SharedPreferences + JSON | SQLite nativo (sin librerías) | El progreso se guarda cada pocos segundos para miles de archivos |
| Biblioteca | En memoria, reescaneo en cada arranque | Índice persistido + escaneo incremental | Leer la duración de cada video es caro |
| Identidad | `song.id` (MediaStore o hash) | `vkey` = id de documento SAF | Favoritos, progreso y correcciones sobreviven a reescaneos |
| Reproducción | Servicio en primer plano + MediaSession | ExoPlayer en la pantalla, sin servicio | Sin procesos en segundo plano |
| Permisos | READ_MEDIA_AUDIO, notificaciones, foreground | Ninguno (SAF) | Menos superficie de fallos |

## Datos (esquema v2, `VideoDb`)
- `video`: índice regenerable (ruta relativa, tamaño, fecha, duración, resolución, extensiones de archivos relacionados). La columna legada `path` de las tablas de identidad queda sin uso: las vistas se derivan de atributos.
- `progress`, `favorite`, `collection`, `collection_item`: datos del usuario, ligados por `vkey` **sin clave foránea**: reescanear o perder un archivo nunca los borra.
- `identity_auto` (calculado, recalculable) y `override_manual` (corrección del usuario, **siempre gana**).
- `work`: metadata externa en caché para funcionar offline.

## Identificación por capas (contrato en `identify/`)
1. Nombre del archivo · 2. Carpeta/ruta · 3. Archivos relacionados · 4. Duración y datos locales ·
5. Búsqueda aproximada · 6. Metadata externa · 7. Corrección manual.
Cada capa aporta evidencia con peso; si la confianza es menor que `Identification.MIN_CONFIDENCE` el video queda en **Sin clasificar**
(con sugerencia opcional, nunca aplicada sola).

## Categorías virtuales
Cada video tiene atributos (categoría, subcategorías, franquicia, creador, temporada/episodio, año). Las vistas son consultas sobre esos
atributos, no copias: un mismo archivo aparece en Videojuegos → Gameplays → Resident Evil → Markiplier y en Películas → Resident Evil.

## Metadata externa (contrato en `metadata/`)
Interfaz `MetadataProvider` + registro de proveedores por tipo. Solo saldría título limpio y año. Resultado guardado en `work` y en disco.

## Motor v0.2 (implementado)
- Paquete `identify`, Kotlin puro (sin Android ni BD): `NameNormalizer` (limpia ruido sin borrar información), `Lexicon` (palabras clave, obras, reglas de carpeta),
  `CreatorRegistry` (semilla + creadores que escribe el usuario), `Evidence`/`Scoring` (suma tipo noisy-OR por categoría),
  `IdentificationEngine`, `IdentifyBatch` (incremental por huella).
- Umbrales: ALTA ≥ 0.85, MEDIA ≥ 0.70 (mínimo para clasificar), BAJA ≥ 0.40, DESCONOCIDA por debajo. Margen de ambigüedad 0.2 dentro del mismo grupo
  (tema: Videojuegos/Películas/Series; formato: Memes/Shorts/YouTube). El tema gana al formato; el formato queda como vista secundaria.
- La evidencia "de apoyo" (duración, vertical, subtítulos, episodios hermanos) solo suma si ya hay evidencia base ≥ 0.3.
- Huella = hash de versión del motor + firma de creadores + nombre, carpeta, tamaño, duración, resolución, relacionados, hermanos. Subir `VERSION` fuerza reidentificar todo.
- Colecciones: `cat:`, `type:`, `work:`, `creator:` y `fav`; consultas sobre atributos (`CollectionIndex`), nunca copias.
- Manual (`override_manual`) gana al leer; recalcular lo automático nunca lo toca. Limitación: la clave `vkey` cambia si el archivo se mueve.
- La metadata externa seguirá siendo una capa más detrás de `MetadataProvider`, sin tocar el motor.

## Fases
0. Esqueleto, escaneo, miniaturas, reproductor, progreso y favoritos.
1. **Motor de identificación + corrección manual + reglas por carpeta (hecho en 0.2).**
2. **Vistas virtuales y colecciones; Home por categorías (hecho en 0.2).** Pendiente: fila "Por revisar".
3. Metadata externa opt-in (primer proveedor), posters en disco.
4. Pulido: orden/filtros, búsqueda, ajustes y temas portados de Music; botón de corregir en el reproductor.
