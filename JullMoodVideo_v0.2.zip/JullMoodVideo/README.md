# JullMood Video 0.2 — identificación local y colecciones virtuales

Reproductor y biblioteca de videos 100 % local. Hereda el stack y el diseño de JullMood Music
(Kotlin + Compose + Media3, mismas versiones de Gradle/AGP/Kotlin) sin copiar nada específico de música.

## Cómo compilar
- **Android Studio:** abrir esta carpeta y ejecutar `app`. (Si no hay `gradlew`, usar Gradle 8.2: Studio lo descarga solo.)
- **GitHub Actions:** subir el contenido de esta carpeta (o el .zip); `.github/workflows/build.yml` genera `JullMoodVideo-debug.apk`.
- Requisitos: JDK 17, Android SDK 34. Paquete/applicationId: `com.jullmood.video` (convive con JullMood Music).

## Qué hace esta base
1. Primer inicio: eliges la carpeta de videos con el selector nativo (SAF). **Sin permisos de almacenamiento.**
2. Escanea la carpeta y subcarpetas (incremental: solo lee archivos nuevos o cambiados) y guarda un índice en SQLite.
3. Miniaturas en memoria + disco, generadas bajo demanda (máx. 2 a la vez).
4. Home tipo Netflix: Continuar viendo, Añadido recientemente, Favoritos y una fila por categoría
   (🎮 Videojuegos, 🎬 Películas, 📺 Series, 😂 Memes, 📱 TikTok/Shorts, ▶️ YouTube, 📦 Otros). Lo que no se puede clasificar con confianza queda en ❓ Sin clasificar.
5. Reproductor ExoPlayer a pantalla completa: reanuda, guarda progreso cada 5 s, marca como visto al 90 %.
6. Favoritos. Pantalla de error legible si la app se cierra por un fallo (heredada de Music).

## Novedades de la 0.2
- **Motor de identificación local por capas** (`identify/`): nombre, carpeta, datos del archivo (duración, orientación), archivos relacionados
  (.srt/.nfo), coincidencia aproximada y contexto de la carpeta. Sin IA, sin red, sin servicios; no analiza fotogramas.
- **Confianza explicable**: ALTA / MEDIA / BAJA / DESCONOCIDA con la evidencia guardada. Por debajo de 0.7 → Sin clasificar (mejor "no sé" que inventar).
  La sugerencia nunca se aplica sola: solo rellena el diálogo de corrección.
- **Colecciones virtuales**: un video no se mueve ni se copia y puede estar en varias vistas (categoría, tipo, obra, creador). Toca el título de una fila para abrirla.
- **Identificar / Corregir** (mantén pulsada una tarjeta o usa el lápiz de la lista): categoría, tipo, título y creador. Se guarda y gana siempre sobre lo automático.
- **Incremental**: cada video guarda una huella; solo se reidentifica lo nuevo o lo que cambió.
- Base de datos v2 (migración solo con columnas nuevas; favoritos y progreso intactos).

## Qué NO hace todavía (a propósito)
Metadata externa (el contrato `metadata/` sigue vacío) y botón de corregir dentro del reproductor.
Limitaciones conocidas: si mueves un archivo de carpeta su clave cambia y se pierde la corrección manual; el léxico inicial (obras, creadores) es pequeño y crece con tus correcciones.

## Pruebas
`gradle testDebugUnitTest` ejecuta las pruebas JVM del motor (`app/src/test/.../IdentificationEngineTest.kt`).

## Estructura
```
app/src/main/java/com/jullmood/video/
  CrashApp.kt, MainActivity.kt
  data/      Video, VideoDb (esquema v2), VideoRepository, Collections
  scan/      VideoScanner (SAF, incremental)
  thumbs/    ThumbCache (memoria + disco)
  identify/  motor de identificación (Kotlin puro): Normalizer, Lexicon, Evidence, Engine, Batch
  metadata/  contrato MetadataProvider (sin proveedores)
  player/    PlayerScreen
  ui/        Theme, LibraryViewModel, Screens
```
