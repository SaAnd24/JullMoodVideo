package com.jullmood.video.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jullmood.video.data.CollectionIndex
import com.jullmood.video.data.Video
import com.jullmood.video.data.VideoRepository
import com.jullmood.video.identify.Category
import com.jullmood.video.identify.ContentType
import com.jullmood.video.identify.CreatorRegistry
import com.jullmood.video.identify.IdentificationEngine
import com.jullmood.video.identify.IdentifyBatch
import com.jullmood.video.scan.VideoScanner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Estado de la biblioteca: carpeta, escaneo, lista, favoritos, progreso, identificación local, colecciones y corrección manual. */
class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("video", Context.MODE_PRIVATE)
    private val repo = VideoRepository(app)
    private var scanJob: Job? = null

    var folder by mutableStateOf<Uri?>(prefs.getString("folder", null)?.let { Uri.parse(it) }); private set
    var videos by mutableStateOf<List<Video>>(emptyList()); private set
    var scanning by mutableStateOf(false); private set
    var scanDone by mutableIntStateOf(0); private set
    var scanTotal by mutableIntStateOf(-1); private set
    var scanError by mutableStateOf<String?>(null); private set
    var playing by mutableStateOf<Video?>(null); private set

    /** Video que se está identificando/corrigiendo a mano (diálogo abierto), o null. */
    var editing by mutableStateOf<Video?>(null); private set

    /** Pila de colecciones virtuales abiertas (ids). La última es la visible. */
    var collectionStack by mutableStateOf<List<String>>(emptyList()); private set

    /** Colecciones derivadas de [videos]; se recalcula solo cuando cambia la lista. */
    val collections: CollectionIndex by derivedStateOf { CollectionIndex.build(videos) }

    init {
        viewModelScope.launch {
            // Se muestra al instante lo que ya hay en la base de datos; luego se identifica lo pendiente y se reescanea.
            videos = withContext(Dispatchers.IO) { runCatching { repo.all() }.getOrDefault(emptyList()) }
            identifyPending()
            if (folder != null) scan()
        }
    }

    /**
     * Identificación incremental: solo se procesan los videos nuevos o cuya huella cambió.
     * Corre en IO; la identificación manual no se toca (vive en otra tabla y gana al leer).
     */
    private suspend fun identifyPending() {
        val current = videos
        if (current.isEmpty()) return
        val list = withContext(Dispatchers.IO) {
            runCatching {
                val engine = IdentificationEngine(CreatorRegistry.of(repo.userCreators()))
                val items = current.map { it.key to it.facts() }
                val results = IdentifyBatch.run(items, repo.identityFingerprints(), engine)
                if (results.isNotEmpty()) repo.saveAutoIdentities(results)
                if (results.isNotEmpty()) repo.all() else null
            }.getOrNull()
        }
        if (list != null) videos = list
    }

    /** Guarda la carpeta elegida con el selector nativo (con permiso persistente) y reescanea. */
    fun chooseFolder(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        folder = uri
        prefs.edit().putString("folder", uri.toString()).apply()
        scan()
    }

    fun scan() {
        val tree = folder ?: return
        if (scanning) return
        val ctx = getApplication<Application>()
        scanJob = viewModelScope.launch {
            scanning = true
            scanError = null
            scanDone = 0
            scanTotal = -1
            try {
                val known = withContext(Dispatchers.IO) { repo.all() }.associateBy { it.key }
                val found = withContext(Dispatchers.IO) {
                    VideoScanner.scan(ctx, tree, known) { done, total -> scanDone = done; scanTotal = total }
                }
                if (found.isEmpty() && known.isNotEmpty()) {
                    // Estabilidad: un resultado vacío con biblioteca previa suele ser un fallo de acceso, no que se borrara todo.
                    scanError = "No se encontró ningún video. Si no es lo esperado, vuelve a elegir la carpeta."
                } else {
                    withContext(Dispatchers.IO) { repo.applyScan(found, System.currentTimeMillis()) }
                    videos = withContext(Dispatchers.IO) { repo.all() }
                    identifyPending()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                scanError = "Sin acceso a la carpeta. Vuelve a elegirla."
            } catch (e: Exception) {
                scanError = "Error al analizar: ${e.javaClass.simpleName}"
            } finally {
                scanning = false
            }
        }
    }

    fun play(v: Video) { playing = v }

    /** Guardado periódico mientras suena. */
    fun saveProgress(v: Video, positionMs: Long, durationMs: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { repo.saveProgress(v.key, positionMs, durationMs) } }
    }

    /** Cierra el reproductor: guarda y refresca la lista en ese orden (así "Continuar viendo" ya viene al día). */
    fun closePlayer(v: Video, positionMs: Long, durationMs: Long) {
        playing = null
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { repo.saveProgress(v.key, positionMs, durationMs) }
                runCatching { repo.all() }.getOrNull()
            }
            if (list != null) videos = list
        }
    }

    fun toggleFavorite(v: Video) {
        val now = !v.favorite
        videos = videos.map { if (it.key == v.key) it.copy(favorite = now) else it }
        viewModelScope.launch(Dispatchers.IO) { runCatching { repo.setFavorite(v.key, now) } }
    }

    // ---------- Colecciones ----------

    fun openCollection(id: String) { collectionStack = collectionStack + id }

    /** Vuelve una colección atrás; devuelve false si no había ninguna abierta. */
    fun closeCollection(): Boolean {
        if (collectionStack.isEmpty()) return false
        collectionStack = collectionStack.dropLast(1)
        return true
    }

    // ---------- Corrección manual ----------

    fun edit(v: Video) { editing = v }

    fun dismissEdit() { editing = null }

    /** Guarda la corrección manual (gana sobre la automática) y recalcula: un creador nuevo puede mejorar otros videos. */
    fun saveManual(v: Video, category: Category, type: ContentType, title: String, creator: String) {
        editing = null
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching {
                    repo.setManual(v.key, category, type, title, creator)
                    repo.all()
                }.getOrNull()
            }
            if (list != null) videos = list
            identifyPending()
        }
    }

    /** Quita la corrección manual: el video vuelve a su identificación automática. */
    fun clearManual(v: Video) {
        editing = null
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { repo.clearManual(v.key); repo.all() }.getOrNull()
            }
            if (list != null) videos = list
            identifyPending()
        }
    }
}
