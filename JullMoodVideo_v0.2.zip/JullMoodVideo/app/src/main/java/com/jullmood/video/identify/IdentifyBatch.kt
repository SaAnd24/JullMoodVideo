package com.jullmood.video.identify

class IdentResult(val key: String, val identification: Identification, val fingerprint: String)

/**
 * Identificación incremental: recibe todos los videos y las huellas guardadas, y solo devuelve resultados para los
 * que son nuevos o cuya información relevante cambió. Pura (sin Android ni base de datos).
 */
object IdentifyBatch {
    fun run(items: List<Pair<String, VideoFacts>>, stored: Map<String, String>, engine: IdentificationEngine): List<IdentResult> {
        val isEp = BooleanArray(items.size)
        val episodesByFolder = HashMap<String, Int>()
        for ((i, item) in items.withIndex()) {
            if (NameNormalizer.hasEpisodeMarker(item.second.name)) {
                isEp[i] = true
                episodesByFolder[item.second.folder] = (episodesByFolder[item.second.folder] ?: 0) + 1
            }
        }
        val out = ArrayList<IdentResult>()
        for ((i, item) in items.withIndex()) {
            val f = item.second
            val siblings = ((episodesByFolder[f.folder] ?: 0) - (if (isEp[i]) 1 else 0)).coerceAtLeast(0)
            val ctx = IdentifyContext(siblingEpisodes = siblings)
            val fp = engine.fingerprint(f, ctx)
            if (stored[item.first] == fp) continue
            out.add(IdentResult(item.first, engine.identify(f, ctx), fp))
        }
        return out
    }
}
