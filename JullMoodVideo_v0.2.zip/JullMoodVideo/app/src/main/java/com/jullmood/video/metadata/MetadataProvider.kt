package com.jullmood.video.metadata

enum class WorkKind { MOVIE, SERIES, GAME, OTHER }

/** Lo único que saldría del dispositivo: título limpio y año. Nunca rutas, URIs ni archivos. */
data class MetadataQuery(val kind: WorkKind, val title: String, val year: Int = 0)

data class WorkInfo(
    val provider: String,
    val externalId: String,
    val kind: WorkKind,
    val title: String,
    val year: Int = 0,
    val posterUrl: String = "",
    val summary: String = ""
)

sealed class MetadataResult {
    data class Found(val items: List<WorkInfo>) : MetadataResult()
    object NotFound : MetadataResult()
    data class Failure(val reason: String, val transient: Boolean) : MetadataResult()
}

/**
 * Un proveedor externo de metadata. La app depende solo de esta interfaz: cambiar o añadir proveedores
 * no toca el resto. Se llama fuera del hilo principal. Los resultados se guardan en la tabla `work` y
 * en disco para que la biblioteca funcione offline. (Fase 5: aún no hay ninguna implementación.)
 */
interface MetadataProvider {
    val id: String
    val kinds: Set<WorkKind>
    fun search(q: MetadataQuery): MetadataResult
}
