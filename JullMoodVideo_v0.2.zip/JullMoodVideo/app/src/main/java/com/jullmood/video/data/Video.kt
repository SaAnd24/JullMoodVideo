package com.jullmood.video.data

import com.jullmood.video.identify.IdSource
import com.jullmood.video.identify.Identification
import com.jullmood.video.identify.VideoFacts

/**
 * Un archivo de video de la biblioteca.
 *
 * [key] es la IDENTIDAD ESTABLE: el id de documento del selector de archivos (p. ej. "primary:Movies/a.mp4").
 * Favoritos, progreso y correcciones manuales se guardan por esta clave, así que sobreviven a reescaneos,
 * a cambiar de carpeta raíz y a reinstalar. Si el archivo se mueve de carpeta, la clave cambia
 * (la reasociación por huella tamaño+duración llegará con el motor de identificación).
 */
data class Video(
    val key: String,
    val uri: String,
    val name: String,
    val folder: String,
    val sizeBytes: Long,
    val modifiedMs: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val addedAt: Long = 0L,
    val positionMs: Long = 0L,
    val watched: Boolean = false,
    val lastPlayedAt: Long = 0L,
    val favorite: Boolean = false,
    /** Extensiones de archivos hermanos con el mismo nombre (subtítulos, .nfo), separadas por coma. Lo rellena el scanner. */
    val related: String = "",
    /** Identificación vigente: la manual si existe, si no la automática, si no [Identification.NONE]. */
    val identity: Identification = Identification.NONE
) {
    /** Título para mostrar: nombre sin extensión y sin guiones bajos. (La limpieza real llegará con la identificación.) */
    val title: String
        get() = name.substringBeforeLast('.').replace('_', ' ').trim().ifEmpty { name }

    /** Título que se muestra: el corregido a mano, o el nombre limpio si el video está clasificado; si no, el nombre del archivo. */
    val displayTitle: String
        get() {
            val id = identity
            if (id.source == IdSource.MANUAL && id.title.isNotBlank()) {
                val ep = if (id.episode > 0) " S%02dE%02d".format(id.season, id.episode) else ""
                val part = if (id.part > 0) " · Parte ${id.part}" else ""
                return id.title + ep + part
            }
            if (id.classified && id.cleanName.isNotBlank()) return id.cleanName
            return title
        }

    /** Lo que ve el motor de identificación (sin depender de esta clase ni de Android). */
    fun facts(): VideoFacts = VideoFacts(
        name = name, folder = folder, sizeBytes = sizeBytes, durationMs = durationMs, width = width, height = height,
        related = related.split(',').filter { it.isNotEmpty() }.toSet()
    )

    val progress: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}
