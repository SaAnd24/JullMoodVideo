package com.jullmood.video.identify

/**
 * Una pista a favor de una categoría. [supporting] = solo refuerza una categoría que ya tiene pistas propias
 * (duración, resolución, archivos hermanos): por sí sola nunca clasifica nada.
 */
internal class Evidence(
    val layer: String,
    val category: Category,
    val weight: Float,
    val note: String,
    val type: ContentType = ContentType.NONE,
    val supporting: Boolean = false
) {
    fun line(): String {
        val w = String.format(java.util.Locale.US, "%.2f", weight)
        return "[$layer] ${category.label} +$w — $note${if (supporting) " (apoyo)" else ""}"
    }
}

internal object Scoring {
    /** Una categoría necesita al menos esto en pistas propias para que las de apoyo cuenten. */
    const val SUPPORT_MIN = 0.3f

    /** Combinación "o ruidoso": cada pista reduce la duda restante. 0.85 + 0.3 -> 0.895. */
    fun score(cat: Category, ev: List<Evidence>): Float {
        var rest = 1f
        var any = false
        for (e in ev) {
            if (e.category == cat && !e.supporting) {
                rest *= (1f - e.weight.coerceIn(0f, 0.99f))
                any = true
            }
        }
        if (!any) return 0f
        val base = 1f - rest
        if (base < SUPPORT_MIN) return base
        for (e in ev) {
            if (e.category == cat && e.supporting) rest *= (1f - e.weight.coerceIn(0f, 0.99f))
        }
        return 1f - rest
    }
}
