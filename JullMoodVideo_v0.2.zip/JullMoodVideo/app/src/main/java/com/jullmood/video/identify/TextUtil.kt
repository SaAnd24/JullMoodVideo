package com.jullmood.video.identify

import java.text.Normalizer

internal object TextUtil {
    private val MARKS = Regex("\\p{Mn}+")

    /** Minúsculas, sin tildes y sin apóstrofes: "Let’s Play" -> "lets play". */
    fun fold(s: String): String {
        val d = Normalizer.normalize(s, Normalizer.Form.NFD)
        return MARKS.replace(d, "").lowercase().replace("'", "").replace("’", "")
    }

    fun isNumeric(s: String): Boolean = s.isNotEmpty() && s.all { it.isDigit() }

    /** Distancia de edición con transposiciones (OSA): "gameplya" -> "gameplay" = 1. */
    fun distance(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        if (n == 0) return m
        if (m == 0) return n
        val d = Array(n + 1) { IntArray(m + 1) }
        for (i in 0..n) d[i][0] = i
        for (j in 0..m) d[0][j] = j
        for (i in 1..n) {
            for (j in 1..m) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = minOf(v, d[i - 2][j - 2] + 1)
                }
                d[i][j] = v
            }
        }
        return d[n][m]
    }

    /** Hash estable de 64 bits (FNV-1a) en hexadecimal; sirve de huella para la identificación incremental. */
    fun hash(s: String): String {
        var h = -3750763034362895579L
        for (c in s) {
            h = h xor c.code.toLong()
            h *= 1099511628211L
        }
        return java.lang.Long.toHexString(h)
    }
}
