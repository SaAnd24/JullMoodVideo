package com.jullmood.video.identify

/**
 * Resultado de normalizar un nombre de archivo.
 * [words] conserva TODO lo potencialmente útil (incluidos "Part 03", el año, números de título…) y solo omite etiquetas
 * técnicas inequívocas (resolución, códec, origen del release). [markerWord] indica qué palabras son marcadores
 * estructurales (temporada, episodio, parte, año); [markerStart] es la posición del primero.
 */
class NormalizedName(
    val raw: String,
    val words: List<String>,
    val markerWord: List<Boolean>,
    val markerStart: Int,
    val season: Int,
    val episode: Int,
    val part: Int,
    val year: Int,
    val episodePattern: Boolean,
    val techTags: List<String>,
    val hasResolution: Boolean,
    val hasReleaseSource: Boolean,
    val yearThenTech: Boolean,
    val youtubeId: Boolean,
    val numericId: Boolean,
    val generic: Boolean
) {
    val cleanName: String get() = words.joinToString(" ")
}

object NameNormalizer {

    private val VIDEO_EXT = setOf("mp4", "mkv", "webm", "avi", "mov", "m4v", "3gp", "ts", "mpg", "mpeg", "wmv", "flv")
    private val SEPARATORS = Regex("[._\\-+~\\[\\](){}|,;:!?#]+")
    private val SPACES = Regex("\\s+")
    private val SE = Regex("^s(\\d{1,2})e(\\d{1,3})$")
    private val NX = Regex("^(\\d{1,2})x(\\d{2,3})$")
    private val SONLY = Regex("^s(\\d{1,2})$")
    private val EONLY = Regex("^e(\\d{1,3})$")
    private val EPNUM = Regex("^(ep|episode|episodio|cap|capitulo)(\\d{1,3})$")
    private val PARTNUM = Regex("^(part|parte|pt)(\\d{1,3})$")
    private val YEAR = Regex("^(19[2-9]\\d|20[0-3]\\d)$")
    private val RES = Regex("^(\\d{3,4}[pi]|[248]k|uhd|fhd|qhd)$")
    private val AUDIO = Regex("^((aac|ac3|eac3|dts|flac|opus|atmos)\\d*|(dd|ddp)\\d+)$")
    private val YT_ID = Regex("\\[([A-Za-z0-9_-]{11})\\]\\s*$")
    private val NUMERIC_ID = Regex("^\\d{17,20}$")
    private val EPISODE_COMPACT = Regex("(?i)(?<![a-z0-9])(s\\d{1,2}[ ._-]?e\\d{1,3}|\\d{1,2}x\\d{2,3})(?![a-z0-9])")

    private val SEASON_WORDS = setOf("season", "temporada", "temp", "saison")
    private val EPISODE_WORDS = setOf("episode", "episodio", "ep", "cap", "capitulo")
    private val PART_WORDS = setOf("part", "parte", "pt")

    private val SOURCES = setOf(
        "bluray", "brrip", "bdrip", "webrip", "webdl", "hdrip", "hdtv", "dvdrip", "dvdscr", "hdcam",
        "remux", "bdremux", "amzn", "hmax", "repack", "proper"
    )
    private val CODECS = setOf("x264", "x265", "h264", "h265", "hevc", "avc", "xvid", "divx", "vp9", "av1", "10bit", "8bit", "hdr", "hdr10", "sdr", "hi10p")
    private val GROUPS = setOf("yify", "yts", "rarbg", "ettv", "eztv", "galaxyrg", "tigole", "ion10")
    private val YT_TECH_SUBSTR = listOf("1080p", "720p", "480p", "2160p", "bluray", "x264", "x265", "webdl", "webrip")

    /** Palabras sin información (nombres de cámara, descargas, grabaciones…). Si no queda nada más, el nombre es genérico. */
    private val GENERIC = setOf(
        "video", "vid", "movie", "clip", "untitled", "new", "sin", "titulo", "recording", "record", "screen",
        "screenrecord", "screenrecording", "screenshot", "capture", "captura", "img", "dsc", "pxl", "mov", "mvi",
        "wa", "whatsapp", "signal", "telegram", "download", "downloaded", "file", "output", "copy", "copia", "test",
        "prueba", "temp", "tmp", "camera", "footage", "raw", "export", "render", "at", "final", "edit", "edited",
        "nuevo", "nueva", "archivo", "grabacion", "pantalla", "de", "sample", "trim", "trimmed", "compressed", "converted"
    )

    private fun stripExtension(name: String): String {
        val dot = name.lastIndexOf('.')
        if (dot <= 0) return name
        return if (name.substring(dot + 1).lowercase() in VIDEO_EXT) name.substring(0, dot) else name
    }

    /** Barato: solo mira si el nombre lleva SxxExx o 2x04. Sirve para contar hermanos de carpeta. */
    fun hasEpisodeMarker(fileName: String): Boolean = EPISODE_COMPACT.containsMatchIn(stripExtension(fileName))

    private fun looksLikeYoutubeId(id: String): Boolean {
        val low = id.lowercase()
        if (YT_TECH_SUBSTR.any { low.contains(it) }) return false
        return id.any { it.isDigit() } || (id.drop(1).any { it.isUpperCase() } && id.any { it.isLowerCase() })
    }

    private fun isNum(s: String): Boolean = s.length in 1..3 && s.all { it.isDigit() }

    fun normalize(fileName: String): NormalizedName {
        var base = stripExtension(fileName).trim()
        var ytId = false
        val m = YT_ID.find(base)
        if (m != null && looksLikeYoutubeId(m.groupValues[1])) {
            ytId = true
            base = base.substring(0, m.range.first)
        }
        val numericId = NUMERIC_ID.matches(base.trim())

        val raw = SEPARATORS.replace(base, " ").split(SPACES).filter { it.isNotEmpty() }
        val n = raw.size
        val low = raw.map { it.lowercase() }
        val drop = BooleanArray(n)
        val marker = BooleanArray(n)
        var season = 0
        var episode = 0
        var part = 0
        var compact = false
        var yearIdx = -1
        var hasRes = false
        var hasSrc = false
        val tech = ArrayList<String>()

        var i = 0
        while (i < n) {
            val l = low[i]
            val next = if (i + 1 < n) low[i + 1] else ""
            var step = 1
            val se = SE.matchEntire(l)
            val nx = NX.matchEntire(l)
            val so = SONLY.matchEntire(l)
            val eo = EONLY.matchEntire(next)
            val ep = EPNUM.matchEntire(l)
            val pn = PARTNUM.matchEntire(l)
            when {
                se != null -> {
                    season = se.groupValues[1].toInt(); episode = se.groupValues[2].toInt()
                    compact = true; marker[i] = true
                }
                nx != null -> {
                    season = nx.groupValues[1].toInt(); episode = nx.groupValues[2].toInt()
                    compact = true; marker[i] = true
                }
                so != null && eo != null -> {
                    season = so.groupValues[1].toInt(); episode = eo.groupValues[1].toInt()
                    compact = true; marker[i] = true; marker[i + 1] = true; step = 2
                }
                l in SEASON_WORDS && isNum(next) -> {
                    season = next.toInt(); marker[i] = true; marker[i + 1] = true; step = 2
                }
                l in EPISODE_WORDS && isNum(next) -> {
                    episode = next.toInt(); marker[i] = true; marker[i + 1] = true; step = 2
                }
                ep != null -> {
                    episode = ep.groupValues[2].toInt(); marker[i] = true
                }
                l in PART_WORDS && isNum(next) -> {
                    part = next.toInt(); marker[i] = true; marker[i + 1] = true; step = 2
                }
                pn != null -> {
                    part = pn.groupValues[2].toInt(); marker[i] = true
                }
                YEAR.matches(l) && i >= 1 -> {
                    yearIdx = i
                }
                l == "web" && (next == "dl" || next == "rip") -> {
                    drop[i] = true; drop[i + 1] = true; hasSrc = true; tech.add(l + next); step = 2
                }
                l == "blu" && next == "ray" -> {
                    drop[i] = true; drop[i + 1] = true; hasSrc = true; tech.add("bluray"); step = 2
                }
                l == "h" && (next == "264" || next == "265") -> {
                    drop[i] = true; drop[i + 1] = true; tech.add(l + next); step = 2
                }
                AUDIO.matches(l) -> {
                    drop[i] = true; tech.add(l)
                    var j = i + 1
                    while (j < n && low[j].length == 1 && low[j][0].isDigit()) { drop[j] = true; j++ }   // "AAC 2.0" -> "aac","2","0"
                    step = j - i
                }
                RES.matches(l) -> { drop[i] = true; hasRes = true; tech.add(l) }
                l in SOURCES || l in GROUPS -> { drop[i] = true; hasSrc = true; tech.add(l) }
                l in CODECS -> { drop[i] = true; tech.add(l) }
            }
            i += step
        }

        var year = 0
        if (yearIdx >= 0) {
            marker[yearIdx] = true
            year = low[yearIdx].toInt()
        }
        val yearThenTech = yearIdx >= 0 && yearIdx + 1 < n && drop[yearIdx + 1]

        val words = ArrayList<String>()
        val markerWord = ArrayList<Boolean>()
        var markerStart = -1
        var meaningful = 0
        for (k in 0 until n) {
            if (drop[k]) continue
            if (marker[k] && markerStart < 0) markerStart = words.size
            words.add(raw[k])
            markerWord.add(marker[k])
            if (!marker[k] && !TextUtil.isNumeric(raw[k]) && TextUtil.fold(raw[k]) !in GENERIC) meaningful++
        }
        if (markerStart < 0) markerStart = words.size

        return NormalizedName(
            raw = fileName, words = words, markerWord = markerWord, markerStart = markerStart,
            season = season, episode = episode, part = part, year = year, episodePattern = compact,
            techTags = tech, hasResolution = hasRes, hasReleaseSource = hasSrc, yearThenTech = yearThenTech,
            youtubeId = ytId, numericId = numericId, generic = meaningful == 0
        )
    }
}
