package com.jullmood.video.thumbs

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import com.jullmood.video.data.Video
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Collections

/**
 * Miniaturas en dos niveles: memoria (LRU por bytes) y disco (cacheDir/thumbs, JPEG; el sistema puede vaciarlo y se regenera).
 * Solo 2 extracciones a la vez para no saturar CPU ni memoria al desplazar una biblioteca grande.
 * La clave incluye la fecha de modificación: si el archivo cambia, se regenera.
 */
object ThumbCache {
    private const val WIDTH = 480

    private val mem = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).coerceAtMost(48L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing: MutableSet<String> = Collections.synchronizedSet(HashSet())
    private val gate = Semaphore(2)

    private fun keyOf(v: Video): String {
        val d = MessageDigest.getInstance("SHA-1").digest("${v.key}|${v.modifiedMs}".toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    /** Solo consulta la memoria (no decodifica nada): permite pintar al instante sin parpadeo. */
    fun peek(v: Video): Bitmap? = mem.get(keyOf(v))

    suspend fun load(ctx: Context, v: Video): Bitmap? = withContext(Dispatchers.IO) {
        val k = keyOf(v)
        mem.get(k)?.let { return@withContext it }
        if (k in missing) return@withContext null
        gate.withPermit {
            mem.get(k)?.let { return@withContext it }
            val file = File(File(ctx.cacheDir, "thumbs").apply { mkdirs() }, "$k.jpg")
            val fromDisk = if (file.exists()) runCatching { BitmapFactory.decodeFile(file.path) }.getOrNull() else null
            val bmp = fromDisk ?: extract(ctx, v)?.also { b ->
                runCatching { FileOutputStream(file).use { out -> b.compress(Bitmap.CompressFormat.JPEG, 80, out) } }
            }
            if (bmp != null) mem.put(k, bmp) else missing.add(k)
            bmp
        }
    }

    /** Fotograma al 10 % de la duración (evita el negro del inicio). */
    private fun extract(ctx: Context, v: Video): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, Uri.parse(v.uri))
            val dur = v.durationMs
            val timeUs = if (dur > 0) (dur * 100L).coerceAtLeast(1_000_000L).coerceAtMost(dur * 1000L) else 1_000_000L
            val frame = r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            val scale = WIDTH.toFloat() / frame.width
            if (scale >= 1f) frame
            else {
                val scaled = Bitmap.createScaledBitmap(frame, WIDTH, (frame.height * scale).toInt().coerceAtLeast(1), true)
                if (scaled !== frame) frame.recycle()
                scaled
            }
        } catch (_: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }
}
