package com.jullmood.video

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullmood.video.ui.LibraryViewModel
import com.jullmood.video.ui.VideoApp
import com.jullmood.video.ui.VideoTheme
import java.io.File

class MainActivity : ComponentActivity() {

    private val vm: LibraryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Si la app se cerró por un error, se muestra en el siguiente arranque (sin tocar el ViewModel).
        val crash = File(filesDir, "crash.txt")
        if (crash.exists()) {
            val text = crash.readText()
            setContent {
                VideoTheme {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("La app se cerró por este error (mantén pulsado para copiar):")
                        Button(onClick = { crash.delete(); recreate() }) { Text("Borrar error y reintentar") }
                        SelectionContainer(Modifier.verticalScroll(rememberScrollState())) {
                            Text(text, fontSize = 11.sp)
                        }
                    }
                }
            }
            return
        }

        setContent { VideoTheme { VideoApp(vm) } }
    }
}
