package com.jullmood.video.player

import android.app.Activity
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.jullmood.video.R
import com.jullmood.video.data.Video
import kotlinx.coroutines.delay

/**
 * Reproductor a pantalla completa. El ExoPlayer vive solo mientras esta pantalla está abierta (sin servicio).
 * Progreso: se guarda cada 5 s mientras suena, al enviar la app a segundo plano (que además pausa) y al cerrar.
 * Reanuda donde se quedó, salvo que ya esté visto o quede menos de 10 s.
 */
@Composable
fun PlayerScreen(video: Video, onSave: (Long, Long) -> Unit, onClose: (Long, Long) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val exo = remember(video.key) { ExoPlayer.Builder(ctx).build() }
    var error by remember(video.key) { mutableStateOf<String?>(null) }

    fun pos(): Long = exo.currentPosition.coerceAtLeast(0L)
    fun dur(): Long = exo.duration.let { if (it == C.TIME_UNSET || it <= 0L) video.durationMs else it }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                error = "No se pudo reproducir este video."
            }
        }
        exo.addListener(listener)
        val resume = video.positionMs >= 5_000L && !video.watched &&
            video.durationMs > 0L && video.positionMs <= video.durationMs - 10_000L
        exo.setMediaItem(MediaItem.fromUri(Uri.parse(video.uri)), if (resume) video.positionMs else 0L)
        exo.prepare()
        exo.playWhenReady = true
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    LaunchedEffect(exo) {
        while (true) {
            delay(5_000)
            if (exo.isPlaying) onSave(pos(), dur())
        }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, exo) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                onSave(pos(), dur())
                exo.pause()
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // Pantalla completa inmersiva mientras se reproduce.
    DisposableEffect(Unit) {
        val window = (view.context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    BackHandler { onClose(pos(), dur()) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = exo
                    useController = true
                    keepScreenOn = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        IconButton(
            onClick = { onClose(pos(), dur()) },
            modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
        ) {
            Icon(painterResource(R.drawable.ic_close), "Cerrar", tint = Color.White)
        }
        error?.let { Text(it, color = Color.White, modifier = Modifier.align(Alignment.Center)) }
    }
}
