package com.jullmood.video.identify

/** Palabra clave: aporta [weight] a [category] y, opcionalmente, sugiere un [type] dentro de esa categoría. */
internal class Kw(val category: Category, val type: ContentType, val weight: Float, val label: String)

/** Obra conocida (semilla pequeña y local; la metadata externa llegará por `metadata/`, no aquí). */
internal class KnownWork(val words: List<String>, val category: Category, val weight: Float, val title: String)

internal class FolderRule(val category: Category, val weight: Float, val type: ContentType)

/**
 * Diccionarios del motor. Todas las claves están en forma "plegada" (minúsculas, sin tildes ni apóstrofes).
 * Ampliar el motor = añadir líneas aquí; no hay lógica en este archivo.
 */
internal object Lexicon {

    val words = HashMap<String, MutableList<Kw>>()
    val phrases = ArrayList<Pair<List<String>, Kw>>()
    val folders = HashMap<String, FolderRule>()
    val works = ArrayList<KnownWork>()
    val aliases = HashMap<String, KnownWork>()
    val genericFolders = HashSet<String>()

    /** Palabras de 7+ letras: candidatas a coincidencia aproximada (errores de escritura). */
    val fuzzyKeys: List<Pair<String, List<Kw>>> by lazy {
        words.entries.filter { it.key.length >= 7 }.map { Pair(it.key, it.value as List<Kw>) }
    }

    private fun kw(word: String, cat: Category, type: ContentType, weight: Float) {
        words.getOrPut(word) { ArrayList() }.add(Kw(cat, type, weight, word))
    }

    private fun kp(phrase: String, cat: Category, type: ContentType, weight: Float) {
        phrases.add(Pair(phrase.split(' '), Kw(cat, type, weight, phrase)))
    }

    private fun kf(names: String, cat: Category, weight: Float, type: ContentType = ContentType.NONE) {
        for (n in names.split(',')) folders[n.trim()] = FolderRule(cat, weight, type)
    }

    private fun work(title: String, cat: Category, weight: Float) {
        works.add(KnownWork(title.split(' ').map { TextUtil.fold(it) }, cat, weight, title))
    }

    private fun game(title: String) = work(title, Category.VIDEOJUEGOS, 0.3f)

    private fun alias(token: String, title: String, weight: Float) {
        aliases[token] = KnownWork(title.split(' ').map { TextUtil.fold(it) }, Category.VIDEOJUEGOS, weight, title)
    }

    init {
        val G = Category.VIDEOJUEGOS
        val M = Category.MEMES
        val S = Category.SHORTS
        val Y = Category.YOUTUBE
        val SE = Category.SERIES
        val P = Category.PELICULAS
        val O = Category.OTROS

        // ---- Videojuegos ----
        for (w in listOf("gameplay", "gameplays", "playthrough", "longplay")) kw(w, G, ContentType.GAMEPLAY, 0.85f)
        for (w in listOf("walkthrough", "walkthru")) kw(w, G, ContentType.WALKTHROUGH, 0.85f)
        for (w in listOf("speedrun", "speedruns", "speedrunning")) kw(w, G, ContentType.SPEEDRUN, 0.85f)
        for (w in listOf("guia", "guias", "guide", "guides")) kw(w, G, ContentType.GUIDE, 0.4f)
        for (w in listOf("compilacion", "compilaciones", "compilation", "compilations")) {
            kw(w, G, ContentType.COMPILATION, 0.25f)
            kw(w, M, ContentType.NONE, 0.25f)
        }
        kw("trailer", G, ContentType.TRAILER, 0.2f)
        for (w in listOf("review", "reviews")) {
            kw(w, G, ContentType.GAME_REVIEW, 0.2f)
            kw(w, Y, ContentType.YT_REVIEW, 0.25f)
        }
        for (w in listOf("ps5", "ps4", "ps3", "ps2", "xbox", "playstation", "nintendo")) kw(w, G, ContentType.NONE, 0.35f)
        kw("dlc", G, ContentType.NONE, 0.4f)
        kp("lets play", G, ContentType.GAMEPLAY, 0.85f)
        kp("no commentary", G, ContentType.GAMEPLAY, 0.6f)
        kp("full game", G, ContentType.GAMEPLAY, 0.5f)
        kp("boss fight", G, ContentType.NONE, 0.5f)

        // ---- Memes ----
        for (w in listOf("meme", "memes", "memazo", "memazos")) kw(w, M, ContentType.NONE, 0.75f)
        kw("shitpost", M, ContentType.NONE, 0.6f)
        kw("dank", M, ContentType.NONE, 0.5f)
        for (w in listOf("funny", "gracioso", "graciosos")) kw(w, M, ContentType.NONE, 0.3f)

        // ---- TikTok / Shorts ----
        for (w in listOf("tiktok", "tiktoks")) kw(w, S, ContentType.NONE, 0.85f)
        for (w in listOf("snaptik", "ssstik", "tikmate", "musicaldown")) kw(w, S, ContentType.NONE, 0.8f)
        for (w in listOf("shorts", "reels", "reel")) kw(w, S, ContentType.NONE, 0.55f)
        kw("instagram", S, ContentType.NONE, 0.45f)
        kp("tik tok", S, ContentType.NONE, 0.85f)
        kp("youtube shorts", S, ContentType.NONE, 0.85f)

        // ---- YouTube ----
        kw("youtube", Y, ContentType.YT_GENERAL, 0.6f)
        for (w in listOf("vlog", "vlogs", "unboxing", "podcast", "livestream")) kw(w, Y, ContentType.YT_GENERAL, 0.5f)
        for (w in listOf("tutorial", "tutoriales", "tutorials")) kw(w, Y, ContentType.YT_TUTORIAL, 0.45f)
        for (w in listOf("reaction", "reaccion")) kw(w, Y, ContentType.YT_GENERAL, 0.4f)
        kp("how to", Y, ContentType.YT_TUTORIAL, 0.4f)
        kp("como hacer", Y, ContentType.YT_TUTORIAL, 0.4f)

        // ---- Series / películas (palabras sueltas; los números de temporada/episodio los resuelve el normalizador) ----
        for (w in listOf("episode", "episodio", "capitulo")) kw(w, SE, ContentType.EPISODE, 0.35f)
        for (w in listOf("temporada", "season")) kw(w, SE, ContentType.SEASON, 0.3f)
        kw("pelicula", P, ContentType.MOVIE, 0.3f)
        kp("pelicula completa", P, ContentType.MOVIE, 0.55f)
        kp("full movie", P, ContentType.MOVIE, 0.5f)
        kp("extended edition", P, ContentType.MOVIE, 0.4f)
        kp("directors cut", P, ContentType.MOVIE, 0.45f)

        // ---- Otros (identificables sin ambigüedad) ----
        kw("screenrecord", O, ContentType.NONE, 0.75f)
        kw("screenrecording", O, ContentType.NONE, 0.75f)
        kp("screen recording", O, ContentType.NONE, 0.75f)
        kp("grabacion de pantalla", O, ContentType.NONE, 0.75f)

        // ---- Carpetas ----
        kf("videojuegos,juegos,juego,games,game,gaming", G, 0.5f)
        kf("gameplay,gameplays", G, 0.55f, ContentType.GAMEPLAY)
        kf("walkthrough,walkthroughs", G, 0.55f, ContentType.WALKTHROUGH)
        kf("speedrun,speedruns", G, 0.55f, ContentType.SPEEDRUN)
        kf("guias,guides", G, 0.5f, ContentType.GUIDE)
        kf("peliculas,pelis,films,film,cine,cinema", P, 0.5f, ContentType.MOVIE)
        // "Movies" es la carpeta por defecto de Android: pesa poco a propósito.
        kf("movies,movie", P, 0.3f, ContentType.MOVIE)
        kf("series,tvshows,tv shows,tv show,temporadas,seasons", SE, 0.5f)
        kf("memes,meme", M, 0.55f)
        kf("tiktok,tiktoks,tik tok", S, 0.6f)
        kf("shorts,reels", S, 0.55f)
        kf("youtube,yt,youtube videos", Y, 0.5f)
        kf("tutorials,tutoriales", Y, 0.4f, ContentType.YT_TUTORIAL)
        kf("screen recordings,screenrecords,screen recorder,grabaciones de pantalla", O, 0.6f)

        // Carpetas que no aportan título.
        genericFolders.addAll(
            listOf(
                "download", "downloads", "descargas", "video", "videos", "dcim", "camera", "pictures", "documents",
                "whatsapp", "whatsapp video", "whatsapp video sent", "telegram", "telegram video", "otros", "varios",
                "misc", "new folder", "nueva carpeta", "especiales", "specials", "extras"
            )
        )

        // ---- Obras conocidas ----
        for (t in listOf(
            "Minecraft", "Fortnite", "Grand Theft Auto", "Red Dead Redemption", "The Legend of Zelda", "Zelda",
            "Super Mario", "Mario Kart", "Pokemon", "Resident Evil", "Silent Hill", "Dark Souls", "Elden Ring",
            "God of War", "The Witcher", "Cyberpunk 2077", "Call of Duty", "Counter Strike", "Valorant",
            "League of Legends", "Among Us", "Five Nights at Freddy's", "The Last of Us", "Hollow Knight",
            "Stardew Valley", "Terraria", "Roblox", "Apex Legends", "Overwatch", "Assassin's Creed", "Skyrim",
            "Fallout", "Far Cry", "Dead Space", "Bioshock", "Metal Gear Solid", "Devil May Cry", "Street Fighter",
            "Tekken", "Mortal Kombat", "Final Fantasy", "Kingdom Hearts", "Sekiro", "Bloodborne", "Baldur's Gate",
            "Diablo", "Halo", "Doom", "GTA"
        )) game(t)

        for (t in listOf(
            "Resident Evil Afterlife", "Resident Evil Extinction", "Resident Evil Retribution",
            "Resident Evil Apocalypse", "Resident Evil The Final Chapter", "Resident Evil Welcome to Raccoon City",
            "Resident Evil Death Island", "Resident Evil Vendetta", "Resident Evil Damnation",
            "Resident Evil Degeneration"
        )) work(t, P, 0.55f)
        for (t in listOf(
            "The Matrix", "Inception", "Interstellar", "The Dark Knight", "Avengers Endgame", "The Godfather",
            "Pulp Fiction", "Fight Club", "The Shawshank Redemption", "Gladiator"
        )) work(t, P, 0.4f)
        for (t in listOf(
            "Breaking Bad", "Game of Thrones", "Stranger Things", "Better Call Saul", "The Mandalorian",
            "The Walking Dead", "The Boys", "Peaky Blinders", "Money Heist", "La Casa de Papel"
        )) work(t, SE, 0.4f)

        // ---- Abreviaturas frecuentes (coincidencia exacta de la palabra) ----
        for (n in listOf(2, 3, 4, 7, 8)) alias("re$n", "Resident Evil $n", 0.45f)
        alias("gta5", "Grand Theft Auto V", 0.45f)
        alias("gtav", "Grand Theft Auto V", 0.45f)
        alias("gta4", "Grand Theft Auto IV", 0.45f)
        alias("csgo", "Counter-Strike: Global Offensive", 0.45f)
        alias("cs2", "Counter-Strike 2", 0.4f)
        alias("fnaf", "Five Nights at Freddy's", 0.45f)
        alias("botw", "The Legend of Zelda: Breath of the Wild", 0.45f)
        alias("totk", "The Legend of Zelda: Tears of the Kingdom", 0.45f)
        alias("bg3", "Baldur's Gate 3", 0.45f)
    }
}
