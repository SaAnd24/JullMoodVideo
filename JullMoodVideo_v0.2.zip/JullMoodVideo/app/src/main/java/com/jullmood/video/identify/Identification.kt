package com.jullmood.video.identify

/** Categorías principales. Las vistas más finas (tipo, obra, creador) son colecciones virtuales derivadas. */
enum class Category(val label: String, val emoji: String) {
    VIDEOJUEGOS("Videojuegos", "🎮"),
    PELICULAS("Películas", "🎬"),
    SERIES("Series", "📺"),
    MEMES("Memes", "😂"),
    SHORTS("TikTok / Shorts", "📱"),
    YOUTUBE("YouTube", "▶️"),
    OTROS("Otros", "📦"),
    SIN_CLASIFICAR("Sin clasificar", "❓");

    val display: String get() = "$emoji $label"

    companion object {
        fun fromName(n: String?): Category = values().firstOrNull { it.name == n } ?: SIN_CLASIFICAR
    }
}

/** Tipo de contenido dentro de una categoría. Ampliable: añadir valores aquí no requiere migrar la base de datos (se guarda el nombre). */
enum class ContentType(val label: String, val plural: String, val category: Category?) {
    // Videojuegos
    GAMEPLAY("Gameplay", "Gameplays", Category.VIDEOJUEGOS),
    GUIDE("Guía", "Guías", Category.VIDEOJUEGOS),
    WALKTHROUGH("Walkthrough", "Walkthroughs", Category.VIDEOJUEGOS),
    GAME_REVIEW("Review", "Reviews", Category.VIDEOJUEGOS),
    TRAILER("Trailer", "Trailers", Category.VIDEOJUEGOS),
    SPEEDRUN("Speedrun", "Speedruns", Category.VIDEOJUEGOS),
    COMPILATION("Compilación", "Compilaciones", Category.VIDEOJUEGOS),
    GAME_OTHER("Otros", "Otros", Category.VIDEOJUEGOS),

    // Películas
    MOVIE("Película", "Películas", Category.PELICULAS),

    // Series
    EPISODE("Episodio", "Episodios", Category.SERIES),
    SEASON("Temporada", "Temporadas", Category.SERIES),

    // YouTube
    YT_GENERAL("Video general", "Videos generales", Category.YOUTUBE),
    YT_TUTORIAL("Tutorial", "Tutoriales", Category.YOUTUBE),
    YT_REVIEW("Review", "Reviews", Category.YOUTUBE),
    YT_GAMEPLAY("Gameplay", "Gameplays", Category.YOUTUBE),
    YT_OTHER("Otros", "Otros", Category.YOUTUBE),

    NONE("", "", null);

    companion object {
        fun fromName(n: String?): ContentType = values().firstOrNull { it.name == n } ?: NONE
        fun forCategory(c: Category): List<ContentType> = values().filter { it.category == c }
    }
}

/** HIGH ≥ 0.85, MEDIUM ≥ [Identification.MIN_CONFIDENCE], LOW ≥ 0.4, UNKNOWN por debajo. Solo HIGH y MEDIUM clasifican. */
enum class Confidence {
    HIGH, MEDIUM, LOW, UNKNOWN;

    companion object {
        fun of(score: Float): Confidence = when {
            score >= 0.85f -> HIGH
            score >= Identification.MIN_CONFIDENCE -> MEDIUM
            score >= 0.4f -> LOW
            else -> UNKNOWN
        }
    }
}

enum class IdSource { AUTO, MANUAL }

/** Mejor hipótesis cuando la confianza no alcanza para clasificar. NUNCA se aplica sola: solo rellena el diálogo de corrección. */
data class Suggestion(
    val category: Category,
    val contentType: ContentType,
    val title: String,
    val creator: String,
    val confidence: Float
) {
    fun encode(): String = listOf(
        category.name, contentType.name, title.replace("|", " "), creator.replace("|", " "), confidence.toString()
    ).joinToString("|")

    companion object {
        fun decode(s: String?): Suggestion? {
            if (s.isNullOrBlank()) return null
            val p = s.split("|")
            if (p.size < 5) return null
            val cat = Category.fromName(p[0])
            if (cat == Category.SIN_CLASIFICAR) return null
            return Suggestion(cat, ContentType.fromName(p[1]), p[2], p[3], p[4].toFloatOrNull() ?: 0f)
        }
    }
}

/**
 * Resultado de identificar un video. [evidence] explica internamente por qué se llegó a la conclusión.
 * Regla de producto: por debajo de [MIN_CONFIDENCE] (o con empate entre categorías) queda en SIN_CLASIFICAR.
 * Una identificación MANUAL siempre gana sobre la automática.
 */
data class Identification(
    val category: Category,
    val contentType: ContentType = ContentType.NONE,
    val title: String = "",
    val creator: String = "",
    val season: Int = 0,
    val episode: Int = 0,
    val part: Int = 0,
    val year: Int = 0,
    val cleanName: String = "",
    val confidence: Float = 0f,
    val level: Confidence = Confidence.UNKNOWN,
    val source: IdSource = IdSource.AUTO,
    val evidence: List<String> = emptyList(),
    val suggestion: Suggestion? = null,
    val also: List<Category> = emptyList()
) {
    val classified: Boolean get() = category != Category.SIN_CLASIFICAR

    /** Vistas virtuales en las que aparece el video. Nunca implican mover ni copiar el archivo. */
    fun collections(): List<VirtualCollection> {
        if (!classified) {
            val c = Category.SIN_CLASIFICAR
            return listOf(VirtualCollection("cat:" + c.name, c.display, CollectionKind.CATEGORY, c))
        }
        val out = ArrayList<VirtualCollection>()
        out += categoryCollection(category)
        for (c in also) if (c != category && c != Category.SIN_CLASIFICAR) out += categoryCollection(c)
        if (contentType != ContentType.NONE && contentType.category == category) {
            out += VirtualCollection("type:${category.name}:${contentType.name}", contentType.plural, CollectionKind.TYPE, category)
        }
        if (title.isNotBlank()) {
            out += VirtualCollection("work:" + TextUtil.fold(title), title, CollectionKind.WORK, category)
        }
        if (creator.isNotBlank()) {
            out += VirtualCollection("creator:" + TextUtil.fold(creator), creator, CollectionKind.CREATOR, category)
        }
        return out
    }

    private fun categoryCollection(c: Category) =
        VirtualCollection("cat:" + c.name, c.display, CollectionKind.CATEGORY, c)

    companion object {
        const val MIN_CONFIDENCE = 0.7f
        val NONE = Identification(Category.SIN_CLASIFICAR)
    }
}

enum class CollectionKind { CATEGORY, TYPE, WORK, CREATOR, FAVORITES }

data class VirtualCollection(
    val id: String,
    val title: String,
    val kind: CollectionKind,
    val category: Category? = null
)

/** Lo que el motor sabe de un archivo. Sin dependencias de Android ni de la base de datos: se puede probar en JVM. */
data class VideoFacts(
    val name: String,
    val folder: String,
    val sizeBytes: Long = 0L,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val related: Set<String> = emptySet()      // extensiones de archivos hermanos con el mismo nombre (srt, nfo…)
)

/** Contexto de otros videos de la misma carpeta (ya calculado, el motor no consulta nada). */
data class IdentifyContext(val siblingEpisodes: Int = 0) {
    companion object { val EMPTY = IdentifyContext() }
}

/**
 * Motor de identificación. Función pura y rápida: sin red, sin E/S, sin Android.
 * Los proveedores de metadata externa (ver `metadata/`) se podrán añadir como una capa más sin tocar esta interfaz.
 */
interface Identifier {
    fun identify(facts: VideoFacts, ctx: IdentifyContext = IdentifyContext.EMPTY): Identification
}
