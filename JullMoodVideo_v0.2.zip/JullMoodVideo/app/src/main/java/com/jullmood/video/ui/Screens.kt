@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.jullmood.video.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullmood.video.R
import com.jullmood.video.data.CollectionIndex
import com.jullmood.video.data.Video
import com.jullmood.video.identify.Category
import com.jullmood.video.identify.ContentType
import com.jullmood.video.identify.IdSource
import com.jullmood.video.player.PlayerScreen
import com.jullmood.video.thumbs.ThumbCache

// ---------- Raíz ----------

@Composable
fun VideoApp(vm: LibraryViewModel) {
    val current = vm.playing
    when {
        current != null -> PlayerScreen(
            video = current,
            onSave = { pos, dur -> vm.saveProgress(current, pos, dur) },
            onClose = { pos, dur -> vm.closePlayer(current, pos, dur) }
        )
        vm.folder == null -> OnboardingScreen(onPick = { vm.chooseFolder(it) })
        vm.collectionStack.isNotEmpty() -> CollectionScreen(vm, vm.collectionStack.last())
        else -> HomeScreen(vm)
    }
    vm.editing?.let { v -> EditIdentityDialog(v, vm) }
}

// ---------- Primer inicio ----------

@Composable
private fun OnboardingScreen(onPick: (Uri) -> Unit) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) onPick(uri)
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("JullMood Video", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            "Elige la carpeta donde tienes tus videos. Todo se queda en tu dispositivo: no se mueve ni se copia ningún archivo.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = { launcher.launch(null) }) { Text("Elegir carpeta") }
    }
}

// ---------- Home ----------

@Composable
private fun HomeScreen(vm: LibraryViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) vm.chooseFolder(uri)
    }
    val videos = vm.videos
    val resume = remember(videos) {
        videos.filter { it.positionMs >= 5_000L && !it.watched }.sortedByDescending { it.lastPlayedAt }.take(20)
    }
    val recent = remember(videos) { videos.sortedByDescending { it.addedAt }.take(20) }
    val favorites = remember(videos) { videos.filter { it.favorite } }
    val index = vm.collections
    val unclassified = remember(videos) { videos.filter { !it.identity.classified } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item(key = "header") {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("JullMood Video", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.scan() }) { Icon(painterResource(R.drawable.ic_refresh), "Reescanear") }
                IconButton(onClick = { picker.launch(null) }) { Icon(painterResource(R.drawable.ic_folder), "Cambiar carpeta") }
            }
        }
        item(key = "status") { StatusLine(vm) }

        shelf("Continuar viendo", resume, vm::play, onEdit = vm::edit)
        shelf("Añadido recientemente", recent, vm::play, onEdit = vm::edit)
        shelf("Favoritos", favorites, vm::play, onEdit = vm::edit)

        // Una fila por categoría con contenido. Un video puede aparecer en varias: las vistas son virtuales.
        val shown = listOf(Category.VIDEOJUEGOS, Category.PELICULAS, Category.SERIES, Category.MEMES, Category.SHORTS, Category.YOUTUBE, Category.OTROS)
        for (cat in shown) {
            val id = CollectionIndex.categoryId(cat)
            val list = index.videos(id)
            shelf("${cat.display} (${list.size})", list.take(30), vm::play, onTitle = { vm.openCollection(id) }, onEdit = vm::edit)
        }

        if (unclassified.isNotEmpty()) {
            item(key = "title:all") { SectionTitle("${Category.SIN_CLASIFICAR.display} (${unclassified.size})") }
            items(unclassified, key = { "all:" + it.key }) { v ->
                VideoRow(v, onClick = { vm.play(v) }, onFavorite = { vm.toggleFavorite(v) }, onEdit = { vm.edit(v) })
            }
        }
    }
}

@Composable
private fun StatusLine(vm: LibraryViewModel) {
    val error = vm.scanError
    val msg: String? = when {
        error != null -> error
        vm.scanning && vm.scanTotal > 0 -> "Analizando ${vm.scanDone} de ${vm.scanTotal}…"
        vm.scanning -> "Buscando videos… ${vm.scanDone}"
        vm.videos.isEmpty() -> "No se encontraron videos en esta carpeta."
        else -> null
    }
    if (msg != null) {
        Text(
            msg, fontSize = 13.sp,
            color = if (error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun SectionTitle(title: String, onClick: (() -> Unit)? = null) {
    val base = if (onClick != null) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    Text(
        if (onClick != null) "$title  ›" else title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
        modifier = base.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp)
    )
}

private fun LazyListScope.shelf(
    title: String,
    list: List<Video>,
    onPlay: (Video) -> Unit,
    onTitle: (() -> Unit)? = null,
    onEdit: (Video) -> Unit = {}
) {
    if (list.isEmpty()) return
    item(key = "title:$title") { SectionTitle(title, onTitle) }
    item(key = "row:$title") {
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.key }) { v -> PosterCard(v, onClick = { onPlay(v) }, onLongClick = { onEdit(v) }) }
        }
    }
}

// ---------- Tarjetas ----------

@Composable
private fun PosterCard(v: Video, onClick: () -> Unit, onLongClick: () -> Unit) {
    Column(Modifier.width(200.dp).clip(RoundedCornerShape(10.dp)).combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            Thumb(v, Modifier.fillMaxSize())
            if (v.progress > 0f) ProgressBar(v.progress, Modifier.align(Alignment.BottomStart))
        }
        Text(
            v.displayTitle, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun VideoRow(v: Video, onClick: () -> Unit, onFavorite: () -> Unit, onEdit: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp))) {
            Thumb(v, Modifier.fillMaxSize())
            if (v.progress > 0f) ProgressBar(v.progress, Modifier.align(Alignment.BottomStart))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(v.displayTitle, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val id = v.identity
            val kind: String? = when {
                id.classified -> listOf(id.category.label, id.contentType.label).filter { it.isNotEmpty() }.joinToString(" · ")
                id.suggestion != null -> "¿${id.suggestion.category.label}?"
                else -> null
            }
            val info = listOfNotNull(
                kind,
                v.durationMs.takeIf { it > 0 }?.let { formatDuration(it) },
                v.folder.takeIf { it.isNotEmpty() }
            ).joinToString(" · ")
            if (info.isNotEmpty()) {
                Text(info, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        IconButton(onClick = onEdit) {
            Icon(painterResource(R.drawable.ic_edit), "Identificar o corregir", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onFavorite) {
            Icon(
                painterResource(if (v.favorite) R.drawable.ic_heart else R.drawable.ic_heart_outline),
                "Favorito",
                tint = if (v.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ProgressBar(fraction: Float, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(3.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
        Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
    }
}

/** Miniatura: si está en memoria se pinta al instante; si no, se genera en segundo plano y se cachea. */
@Composable
private fun Thumb(v: Video, modifier: Modifier = Modifier) {
    val appCtx = LocalContext.current.applicationContext
    val bmp by produceState<Bitmap?>(ThumbCache.peek(v), v.key, v.modifiedMs) {
        value = ThumbCache.peek(v) ?: ThumbCache.load(appCtx, v)
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant)) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

// ---------- Colecciones virtuales ----------

@Composable
private fun CollectionScreen(vm: LibraryViewModel, id: String) {
    BackHandler { vm.closeCollection() }
    val index = vm.collections
    val title = index.meta[id]?.title ?: "Colección"
    val list = index.videos(id)
    val subs = remember(index, id) { if (id.startsWith("cat:")) index.subCollections(id) else emptyList() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item(key = "chead") {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.closeCollection() }) { Icon(painterResource(R.drawable.ic_close), "Volver") }
                Text("$title (${list.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (subs.isNotEmpty()) {
            item(key = "csubs") {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(subs, key = { it.id }) { c ->
                        AssistChip(onClick = { vm.openCollection(c.id) }, label = { Text("${c.title} (${index.count(c.id)})") })
                    }
                }
            }
        }
        items(list, key = { "c:" + it.key }) { v ->
            VideoRow(v, onClick = { vm.play(v) }, onFavorite = { vm.toggleFavorite(v) }, onEdit = { vm.edit(v) })
        }
    }
}

// ---------- Identificar / Corregir ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EditIdentityDialog(v: Video, vm: LibraryViewModel) {
    val id = v.identity
    // Valores iniciales: lo manual, si no lo automático clasificado, si no la sugerencia (solo rellena, nunca se aplica sola).
    val sug = id.suggestion
    val startCat: Category? = when {
        id.classified -> id.category
        sug != null -> sug.category
        else -> null
    }
    val startType = if (id.classified) id.contentType else sug?.contentType ?: ContentType.NONE
    var category by remember(v.key) { mutableStateOf(startCat) }
    var type by remember(v.key) { mutableStateOf(startType) }
    var title by remember(v.key) { mutableStateOf(if (id.classified) id.title else sug?.title ?: "") }
    var creator by remember(v.key) { mutableStateOf(if (id.classified) id.creator else sug?.creator ?: "") }
    val pickable = listOf(Category.VIDEOJUEGOS, Category.PELICULAS, Category.SERIES, Category.MEMES, Category.SHORTS, Category.YOUTUBE, Category.OTROS)

    AlertDialog(
        onDismissRequest = { vm.dismissEdit() },
        title = { Text("Identificar / Corregir") },
        text = {
            LazyColumn {
                item {
                    Text(v.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    val why = when {
                        id.source == IdSource.MANUAL -> "Corregido por ti."
                        id.classified -> "Automático (${id.level.name.lowercase()}): " + id.evidence.take(3).joinToString("; ")
                        sug != null -> "No hay certeza suficiente. Sugerencia: ${sug.category.label}. Confírmala o cámbiala."
                        else -> "No hay pistas suficientes para clasificarlo."
                    }
                    Text(why, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Text("Categoría", fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (c in pickable) {
                            FilterChip(
                                selected = category == c,
                                onClick = { if (category != c) { category = c; type = ContentType.NONE } },
                                label = { Text(c.display, fontSize = 12.sp) }
                            )
                        }
                    }
                    val types = category?.let { ContentType.forCategory(it) }.orEmpty()
                    if (types.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Tipo", fontWeight = FontWeight.SemiBold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (t in types) {
                                FilterChip(selected = type == t, onClick = { type = if (type == t) ContentType.NONE else t }, label = { Text(t.label, fontSize = 12.sp) })
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(title, { title = it }, label = { Text("Título / obra") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(creator, { creator = it }, label = { Text("Creador (opcional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = {
            TextButton(enabled = category != null, onClick = { category?.let { vm.saveManual(v, it, type, title, creator) } }) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (id.source == IdSource.MANUAL) TextButton(onClick = { vm.clearManual(v) }) { Text("Quitar corrección") }
                TextButton(onClick = { vm.dismissEdit() }) { Text("Cancelar") }
            }
        }
    )
}
