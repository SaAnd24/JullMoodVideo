package com.jullmood.video.data

import com.jullmood.video.identify.Category
import com.jullmood.video.identify.CollectionKind
import com.jullmood.video.identify.VirtualCollection

/**
 * Colecciones virtuales: consultas sobre los atributos de identificación, NUNCA copias ni movimientos de archivos.
 * Un mismo video aparece en varias (categoría, tipo, obra, creador, favoritos) y todas apuntan al mismo archivo local.
 */
class CollectionIndex private constructor(
    private val members: Map<String, List<Video>>,
    val meta: Map<String, VirtualCollection>
) {
    fun videos(id: String): List<Video> = members[id].orEmpty()

    fun count(id: String): Int = members[id]?.size ?: 0

    /** Sub-vistas de una categoría: tipos de contenido siempre; obras y creadores solo si tienen 2+ videos. */
    fun subCollections(categoryId: String): List<VirtualCollection> {
        val cat = meta[categoryId]?.category ?: return emptyList()
        return meta.values
            .filter {
                it.category == cat && (
                    it.kind == CollectionKind.TYPE ||
                        ((it.kind == CollectionKind.WORK || it.kind == CollectionKind.CREATOR) && count(it.id) >= 2)
                    )
            }
            .sortedWith(
                compareBy<VirtualCollection>(
                    { if (it.kind == CollectionKind.TYPE) 0 else 1 },
                    { -count(it.id) },
                    { it.title.lowercase() }
                )
            )
            .take(40)
    }

    companion object {
        const val FAVORITES_ID = "fav"

        fun categoryId(c: Category): String = "cat:" + c.name

        fun build(videos: List<Video>): CollectionIndex {
            val members = HashMap<String, MutableList<Video>>()
            val meta = HashMap<String, VirtualCollection>()
            for (v in videos) {
                for (c in v.identity.collections()) {
                    if (!meta.containsKey(c.id)) meta[c.id] = c
                    members.getOrPut(c.id) { ArrayList() }.add(v)
                }
                if (v.favorite) {
                    if (!meta.containsKey(FAVORITES_ID)) {
                        meta[FAVORITES_ID] = VirtualCollection(FAVORITES_ID, "⭐ Favoritos", CollectionKind.FAVORITES)
                    }
                    members.getOrPut(FAVORITES_ID) { ArrayList() }.add(v)
                }
            }
            return CollectionIndex(members, meta)
        }
    }
}
