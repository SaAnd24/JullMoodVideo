package com.jullmood.video.identify

/**
 * Motor de identificación por capas. Cada capa solo AÑADE evidencias; la decisión se toma al final, combinándolas:
 *
 *  1. Nombre del archivo (normalizado)     4. Archivos relacionados (subtítulos, .nfo)
 *  2. Carpeta y ruta                       5. Búsqueda aproximada (errores de escritura, abreviaturas)
 *  3. Datos del archivo (duración, formato) 6. Contexto de hermanos de carpeta
 *
 * Filosofía: es mejor "Sin clasificar" que una respuesta inventada. Por eso:
 *  - hace falta confianza ≥ [Identification.MIN_CONFIDENCE];
 *  - las pistas de apoyo (duración, formato…) nunca clasifican por sí solas;
 *  - si dos categorías del mismo grupo quedan muy cerca, se declara ambiguo y no se clasifica.
 */
class IdentificationEngine(private val creators: CreatorRegistry = CreatorRegistry.DEFAULT) : Identifier {

    private class FolderInfo(val title: String, val season: Int, val creator: String)
    private class CreatorAt(val name: String, val start: Int, val size: Int)
    private class SeqHit(val start: Int, val fuzzy: Boolean)

    override fun identify(facts: VideoFacts, ctx: IdentifyContext): Identification {
        val nn = NameNormalizer.normalize(facts.name)
        val fw = nn.words.map { TextUtil.fold(it) }
        val stop = BooleanArray(fw.size)
        val ev = ArrayList<Evidence>()
        val notes = ArrayList<String>()

        // 1 + 5. Nombre: estructura, palabras clave, frases, aproximadas.
        nameLayer(nn, fw, stop, ev)
        if (nn.generic && ev.isEmpty()) notes.add("[nombre] nombre genérico: no contiene información para identificar")

        // Creador (en el nombre).
        var creatorAt: CreatorAt? = null
        for (i in fw.indices) {
            if (nn.markerWord[i]) continue
            val m = creators.find(fw, i)
            if (m != null) {
                creatorAt = CreatorAt(m.name, i, m.size)
                for (k in i until i + m.size) stop[k] = true
                ev.add(Evidence("nombre", Category.YOUTUBE, 0.35f, "creador conocido «${m.name}»", ContentType.YT_GENERAL))
                break
            }
        }

        // Obras conocidas y abreviaturas (en el nombre).
        val aliasTitle = worksLayer(fw, ev, "nombre", 1f)

        // 2. Carpeta.
        val folder = folderLayer(facts.folder, ev)

        // 3, 4, 6. Datos del archivo, archivos relacionados, hermanos (todo apoyo).
        fileLayer(facts, ev)
        relatedLayer(facts, ev)
        if (ctx.siblingEpisodes >= 2 && (nn.episode > 0 || nn.season > 0)) {
            ev.add(Evidence("hermanos", Category.SERIES, 0.35f, "${ctx.siblingEpisodes} videos de la carpeta con patrón de episodio", ContentType.EPISODE, true))
        }

        return decide(facts, nn, fw, stop, ev, notes, creatorAt, aliasTitle, folder)
    }

    // ---------- Decisión ----------

    private fun groupOf(c: Category): Int = when (c) {
        Category.VIDEOJUEGOS, Category.PELICULAS, Category.SERIES -> 0   // tema
        Category.MEMES, Category.SHORTS, Category.YOUTUBE -> 1            // formato / origen
        else -> 2
    }

    private fun decide(
        facts: VideoFacts, nn: NormalizedName, fw: List<String>, stop: BooleanArray, ev: List<Evidence>,
        notes: MutableList<String>, creatorAt: CreatorAt?, aliasTitle: String?, folder: FolderInfo
    ): Identification {
        val cands = ArrayList<Pair<Category, Float>>()
        for (c in Category.values()) {
            if (c == Category.SIN_CLASIFICAR) continue
            val s = Scoring.score(c, ev)
            if (s > 0f) cands.add(Pair(c, s))
        }
        cands.sortByDescending { it.second }
        val qualified = cands.filter { it.second >= Identification.MIN_CONFIDENCE }
        // Si hay un tema (videojuego/película/serie) con confianza suficiente, el formato (YouTube, Memes…) pasa a vista secundaria.
        val topical = qualified.filter { groupOf(it.first) == 0 }
        val pool = if (topical.isNotEmpty()) topical else qualified

        var winner: Category? = null
        var wScore = 0f
        var ambiguous = false
        if (pool.isNotEmpty()) {
            val top = pool[0]
            val rival = cands.firstOrNull { it.first != top.first && groupOf(it.first) == groupOf(top.first) }
            if (rival != null && top.second - rival.second < MARGIN) {
                ambiguous = true
                notes.add("[decisión] ambiguo entre ${top.first.label} (${fmt(top.second)}) y ${rival.first.label} (${fmt(rival.second)}): no se clasifica")
            } else {
                winner = top.first
                wScore = top.second
            }
        }

        val lines = ArrayList<String>()
        lines.addAll(notes.filter { it.startsWith("[nombre]") })
        for (e in ev.sortedByDescending { it.weight }) lines.add(e.line())
        lines.addAll(notes.filter { !it.startsWith("[nombre]") })

        val win: Category? = winner
        if (win != null) {
            val also = qualified.map { it.first }.filter { it != win }
            val fields = fieldsFor(win, nn, stop, ev, creatorAt, aliasTitle, folder)
            lines.add("[decisión] ${win.label} con confianza ${fmt(wScore)} (${Confidence.of(wScore)})")
            return Identification(
                category = win, contentType = fields.type, title = fields.title, creator = fields.creator,
                season = fields.season, episode = nn.episode, part = nn.part, year = nn.year,
                cleanName = if (nn.generic) "" else nn.cleanName,
                confidence = wScore, level = Confidence.of(wScore), source = IdSource.AUTO,
                evidence = lines, suggestion = null, also = also
            )
        }

        // Sin clasificar. Si hay una hipótesis razonable queda como sugerencia, NUNCA aplicada.
        var suggestion: Suggestion? = null
        var level = Confidence.UNKNOWN
        var conf = 0f
        if (cands.isNotEmpty()) {
            val best = cands[0]
            conf = best.second
            level = Confidence.of(best.second)
            if (level == Confidence.MEDIUM || level == Confidence.HIGH) level = Confidence.LOW   // ambiguo: nunca por encima de LOW
            if (best.second >= LOW_MIN) {
                val f = fieldsFor(best.first, nn, stop, ev, creatorAt, aliasTitle, folder)
                suggestion = Suggestion(best.first, f.type, f.title, f.creator, best.second)
                lines.add("[decisión] sin clasificar: confianza insuficiente (mejor hipótesis: ${best.first.label} ${fmt(best.second)})")
            } else {
                lines.add("[decisión] sin clasificar: evidencia insuficiente")
            }
        } else {
            lines.add("[decisión] sin clasificar: sin evidencias")
        }
        return Identification(
            category = Category.SIN_CLASIFICAR, season = nn.season, episode = nn.episode, part = nn.part, year = nn.year,
            confidence = conf, level = level, source = IdSource.AUTO, evidence = lines, suggestion = suggestion
        )
    }

    private class Fields(val type: ContentType, val title: String, val creator: String, val season: Int)

    private fun fieldsFor(
        cat: Category, nn: NormalizedName, stop: BooleanArray, ev: List<Evidence>,
        creatorAt: CreatorAt?, aliasTitle: String?, folder: FolderInfo
    ): Fields {
        var type = ContentType.NONE
        var bw = 0f
        for (e in ev) {
            if (e.category == cat && e.type != ContentType.NONE && e.type.category == cat && e.weight > bw) {
                type = e.type
                bw = e.weight
            }
        }
        if (type == ContentType.NONE) {
            type = when (cat) {
                Category.PELICULAS -> ContentType.MOVIE
                Category.SERIES -> if (nn.episode > 0) ContentType.EPISODE else if (nn.season > 0 || folder.season > 0) ContentType.SEASON else ContentType.NONE
                else -> ContentType.NONE
            }
        }
        var title = ""
        if (cat == Category.VIDEOJUEGOS || cat == Category.PELICULAS || cat == Category.SERIES) {
            title = aliasTitle ?: if (nn.generic) "" else titleRun(nn.words, stop, nn.markerStart)
            if (isJunk(title)) title = ""
            if (title.isEmpty()) title = folder.title
            title = caseFix(title)
        }
        val creator = creatorAt?.name ?: folder.creator
        val season = if (nn.season > 0) nn.season else if (cat == Category.SERIES) folder.season else 0
        return Fields(type, title, creator, season)
    }

    // ---------- Capas ----------

    private fun nameLayer(nn: NormalizedName, fw: List<String>, stop: BooleanArray, ev: MutableList<Evidence>) {
        if (nn.episodePattern) {
            ev.add(Evidence("nombre", Category.SERIES, 0.9f, "patrón temporada/episodio (T${nn.season} E${nn.episode})", ContentType.EPISODE))
        } else if (nn.season > 0 && nn.episode > 0) {
            ev.add(Evidence("nombre", Category.SERIES, 0.85f, "temporada ${nn.season} y episodio ${nn.episode}", ContentType.EPISODE))
        } else if (nn.episode > 0) {
            ev.add(Evidence("nombre", Category.SERIES, 0.55f, "número de episodio ${nn.episode}", ContentType.EPISODE))
        } else if (nn.season > 0) {
            ev.add(Evidence("nombre", Category.SERIES, 0.6f, "número de temporada ${nn.season}", ContentType.SEASON))
        }
        if (nn.year > 0) {
            ev.add(Evidence("nombre", Category.PELICULAS, 0.3f, "año ${nn.year}", ContentType.MOVIE))
        }
        if (nn.yearThenTech) {
            ev.add(Evidence("nombre", Category.PELICULAS, 0.5f, "año seguido de etiquetas de release (${nn.techTags.joinToString(" ")})", ContentType.MOVIE))
        }
        if (nn.hasReleaseSource) {
            ev.add(Evidence("nombre", Category.PELICULAS, 0.25f, "etiqueta de origen de release", ContentType.MOVIE))
        }
        if (nn.youtubeId) {
            ev.add(Evidence("nombre", Category.YOUTUBE, 0.8f, "identificador de YouTube entre corchetes", ContentType.YT_GENERAL))
        }
        if (nn.numericId) {
            ev.add(Evidence("nombre", Category.SHORTS, 0.55f, "nombre numérico largo (descarga típica de TikTok)"))
        }

        var i = 0
        while (i < fw.size) {
            var consumed = 1
            val phrase = matchPhrase(fw, i)
            if (phrase != null) {
                addKw(ev, phrase.second, 1f, "frase «${phrase.second.label}»")
                for (k in i until i + phrase.first.size) stop[k] = true
                consumed = phrase.first.size
            } else if (!nn.markerWord[i]) {
                val w = fw[i]
                val exact = Lexicon.words[w]
                if (exact != null) {
                    for (k in exact) addKw(ev, k, 1f, "palabra «$w»")
                    stop[i] = true
                } else if (w.length >= 7 && !TextUtil.isNumeric(w)) {
                    for (entry in Lexicon.fuzzyKeys) {
                        val key = entry.first
                        if (Math.abs(key.length - w.length) <= 1 && TextUtil.distance(key, w) == 1) {
                            for (k in entry.second) addKw(ev, k, FUZZY, "palabra «$w» ≈ «$key» (aproximada)")
                            stop[i] = true
                            break
                        }
                    }
                }
            }
            i += consumed
        }
    }

    private fun addKw(ev: MutableList<Evidence>, k: Kw, factor: Float, note: String) {
        ev.add(Evidence("nombre", k.category, k.weight * factor, note, k.type))
    }

    private fun matchPhrase(fw: List<String>, i: Int): Pair<List<String>, Kw>? {
        for (p in Lexicon.phrases) {
            val pw = p.first
            if (i + pw.size > fw.size) continue
            var ok = true
            for (j in pw.indices) if (fw[i + j] != pw[j]) { ok = false; break }
            if (ok) return Pair(pw, p.second)
        }
        return null
    }

    private fun findSeq(fw: List<String>, pat: List<String>): SeqHit? {
        if (pat.isEmpty() || fw.size < pat.size) return null
        for (s in 0..(fw.size - pat.size)) {
            var fuzzy = false
            var ok = true
            for (j in pat.indices) {
                val a = fw[s + j]
                val b = pat[j]
                if (a == b) continue
                if (b.length >= 6 && a.length >= 5 && TextUtil.distance(a, b) <= 1) { fuzzy = true; continue }
                ok = false
                break
            }
            if (ok) return SeqHit(s, fuzzy)
        }
        return null
    }

    /** Obras conocidas y abreviaturas. Devuelve el título canónico si coincidió una abreviatura (p. ej. "re4"). */
    private fun worksLayer(fw: List<String>, ev: MutableList<Evidence>, layer: String, factor: Float): String? {
        for (w in Lexicon.works) {
            val hit = findSeq(fw, w.words) ?: continue
            val f = factor * (if (hit.fuzzy) FUZZY else 1f)
            ev.add(Evidence(layer, w.category, w.weight * f, "título conocido «${w.title}»${if (hit.fuzzy) " (aproximado)" else ""}"))
        }
        var alias: String? = null
        for (word in fw) {
            val a = Lexicon.aliases[word] ?: continue
            ev.add(Evidence(layer, a.category, a.weight * factor, "abreviatura «$word» = ${a.title}"))
            if (alias == null) alias = a.title
        }
        return alias
    }

    private fun folderLayer(folder: String, ev: MutableList<Evidence>): FolderInfo {
        val segs = folder.split('/').filter { it.isNotBlank() }
        val best = HashMap<Category, Evidence>()
        var cand = ""
        var season = 0
        var creator = ""
        for ((idx, seg) in segs.withIndex()) {
            val up = segs.size - 1 - idx
            val factor = (if (up == 0) 1f else 0.85f) * (if (up > 3) 0.7f else 1f)
            val key = TextUtil.fold(seg).replace(Regex("[._\\-]+"), " ").trim()
            val rule = Lexicon.folders[key]
            if (rule != null) {
                val e = Evidence("carpeta", rule.category, rule.weight * factor, "carpeta «$seg»", rule.type)
                val cur = best[rule.category]
                if (cur == null || e.weight > cur.weight) best[rule.category] = e
            }
            val nn = NameNormalizer.normalize(seg)
            if (nn.season > 0 && nn.episode == 0) {
                season = nn.season
                val e = Evidence("carpeta", Category.SERIES, 0.45f * factor, "carpeta de temporada «$seg»", ContentType.SEASON)
                val cur = best[Category.SERIES]
                if (cur == null || e.weight > cur.weight) best[Category.SERIES] = e
                continue
            }
            val fw = nn.words.map { TextUtil.fold(it) }
            var creatorHere = false
            for (i in fw.indices) {
                val m = creators.find(fw, i)
                if (m != null) {
                    creator = m.name
                    creatorHere = true
                    ev.add(Evidence("carpeta", Category.YOUTUBE, 0.35f * factor, "carpeta de creador conocido «${m.name}»", ContentType.YT_GENERAL))
                    break
                }
            }
            worksLayer(fw, ev, "carpeta", factor * 0.85f)
            if (rule == null && !creatorHere && key !in Lexicon.genericFolders && seg.any { it.isLetter() }) {
                val t = titleRun(nn.words, keywordStops(fw), nn.markerStart)
                if (!isJunk(t)) cand = t
            }
        }
        ev.addAll(best.values)
        return FolderInfo(cand, season, creator)
    }

    private fun keywordStops(fw: List<String>): BooleanArray {
        val s = BooleanArray(fw.size)
        for (i in fw.indices) if (Lexicon.words.containsKey(fw[i])) s[i] = true
        return s
    }

    /** Datos del archivo: solo refuerzan categorías que ya tienen pistas propias. */
    private fun fileLayer(facts: VideoFacts, ev: MutableList<Evidence>) {
        val min = facts.durationMs / 60000.0
        val sec = facts.durationMs / 1000.0
        val vertical = facts.height > facts.width && facts.width > 0
        if (facts.durationMs > 0) {
            if (min in 70.0..240.0) ev.add(Evidence("archivo", Category.PELICULAS, 0.1f, "duración típica de película (${min.toInt()} min)", ContentType.MOVIE, true))
            if (min in 15.0..75.0) ev.add(Evidence("archivo", Category.SERIES, 0.15f, "duración típica de episodio (${min.toInt()} min)", ContentType.EPISODE, true))
            if (sec <= 90.0 && vertical) {
                ev.add(Evidence("archivo", Category.SHORTS, 0.35f, "video vertical de ${sec.toInt()} s", ContentType.NONE, true))
            } else if (sec <= 90.0) {
                ev.add(Evidence("archivo", Category.SHORTS, 0.15f, "video muy corto (${sec.toInt()} s)", ContentType.NONE, true))
            }
            if (sec <= 120.0) ev.add(Evidence("archivo", Category.MEMES, 0.1f, "video corto (${sec.toInt()} s)", ContentType.NONE, true))
        }
    }

    private fun relatedLayer(facts: VideoFacts, ev: MutableList<Evidence>) {
        if (facts.related.isEmpty()) return
        if ("nfo" in facts.related) {
            ev.add(Evidence("relacionados", Category.PELICULAS, 0.25f, "archivo .nfo con el mismo nombre", ContentType.MOVIE, true))
            ev.add(Evidence("relacionados", Category.SERIES, 0.25f, "archivo .nfo con el mismo nombre", ContentType.NONE, true))
        }
        if (facts.related.any { it != "nfo" }) {
            ev.add(Evidence("relacionados", Category.PELICULAS, 0.15f, "subtítulos con el mismo nombre", ContentType.MOVIE, true))
            ev.add(Evidence("relacionados", Category.SERIES, 0.15f, "subtítulos con el mismo nombre", ContentType.NONE, true))
        }
    }

    // ---------- Títulos ----------

    /** Primera tanda de palabras que no son palabra clave ni marcador (ni parte del creador). */
    private fun titleRun(words: List<String>, stop: BooleanArray, markerStart: Int): String {
        val out = ArrayList<String>()
        var i = 0
        while (i < words.size && i < markerStart) {
            if (i < stop.size && stop[i]) {
                if (out.isNotEmpty()) break
                i++
                continue
            }
            out.add(words[i])
            i++
        }
        return out.joinToString(" ")
    }

    private fun isJunk(t: String): Boolean {
        if (t.isBlank()) return true
        return t.split(' ').all { TextUtil.isNumeric(it) || it.length < 2 }
    }

    /** Solo repara títulos TODO en minúsculas o TODO en mayúsculas; los mixtos se respetan. */
    private fun caseFix(t: String): String {
        if (t.isEmpty()) return t
        val allLower = t == t.lowercase()
        val allUpper = t == t.uppercase()
        if (!allLower && !allUpper) return t
        return t.split(' ').joinToString(" ") { w ->
            if (allUpper && w.length <= 3) w else w.lowercase().replaceFirstChar { c -> c.uppercaseChar() }
        }
    }

    private fun fmt(f: Float): String = String.format(java.util.Locale.US, "%.2f", f)

    // ---------- Incremental ----------

    /**
     * Huella de todo lo que influye en el resultado. Si no cambia, no se vuelve a identificar.
     * Incluye la versión del motor (al ampliar reglas, súbela y se reanalizará una sola vez) y los creadores del usuario.
     */
    fun fingerprint(facts: VideoFacts, ctx: IdentifyContext): String {
        val s = "$VERSION|${creators.signature}|${facts.name}|${facts.folder}|${facts.sizeBytes}|${facts.durationMs}|" +
            "${facts.width}|${facts.height}|${facts.related.sorted().joinToString(",")}|${minOf(ctx.siblingEpisodes, 3)}"
        return TextUtil.hash(s)
    }

    companion object {
        const val VERSION = 1
        private const val MARGIN = 0.2f      // diferencia mínima con la categoría rival del mismo grupo
        private const val FUZZY = 0.8f       // las coincidencias aproximadas pesan menos
        private const val LOW_MIN = 0.4f     // por debajo no se ofrece ni sugerencia
    }
}
