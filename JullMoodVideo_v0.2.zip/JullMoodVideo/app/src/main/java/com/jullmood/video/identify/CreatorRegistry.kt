package com.jullmood.video.identify

class CreatorMatch(val name: String, val size: Int)

/**
 * Creadores conocidos: una semilla pequeña + los que el usuario ha escrito en correcciones manuales.
 * Se compara sin tildes, mayúsculas ni espacios ("Mr Beast" = "MrBeast"). Solo coincidencia exacta: conservador.
 */
class CreatorRegistry private constructor(private val byKey: Map<String, String>, val signature: String) {

    /** Busca un creador que empiece en la palabra [start] de [folded] (palabras ya plegadas). */
    fun find(folded: List<String>, start: Int): CreatorMatch? {
        var size = minOf(3, folded.size - start)
        while (size >= 1) {
            val key = keyOf(folded.subList(start, start + size))
            if (key.length >= 4) {
                val display = byKey[key]
                if (display != null) return CreatorMatch(display, size)
            }
            size--
        }
        return null
    }

    companion object {
        private val SEED = listOf(
            "Markiplier", "PewDiePie", "Jacksepticeye", "Vegetta777", "Willyrex", "elrubiusOMG", "Rubius",
            "AuronPlay", "Ibai", "TheGrefg", "MrBeast", "GameGrumps", "AngryJoe", "videogamedunkey", "Zack Scott"
        )

        fun keyOf(parts: List<String>): String = parts.joinToString("").filter { it.isLetterOrDigit() }

        val DEFAULT: CreatorRegistry = of(emptyList())

        fun of(user: List<String>): CreatorRegistry {
            val map = HashMap<String, String>()
            for (s in SEED) map[keyOf(listOf(TextUtil.fold(s)))] = s
            val userKeys = ArrayList<String>()
            for (u in user) {
                val t = u.trim()
                if (t.isEmpty()) continue
                val k = keyOf(listOf(TextUtil.fold(t)))
                if (k.length < 4) continue
                map[k] = t
                userKeys.add(k)
            }
            userKeys.sort()
            return CreatorRegistry(map, TextUtil.hash(userKeys.joinToString("|")))
        }
    }
}
