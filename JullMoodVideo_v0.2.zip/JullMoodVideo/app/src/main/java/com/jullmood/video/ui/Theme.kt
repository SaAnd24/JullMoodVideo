package com.jullmood.video.ui

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView

// Misma paleta oscura que JullMood Music. (Los temas múltiples de Music se pueden portar más adelante.)
private val Bg = Color(0xFF0F1115)
private val SurfaceC = Color(0xFF181B22)
private val Variant = Color(0xFF252935)
private val Muted = Color(0xFFA3A8B8)
private val OnBg = Color(0xFFEEF0F6)
private val Accent = Color(0xFF8EA8FF)

private val Scheme = darkColorScheme(
    primary = Accent, onPrimary = Color(0xFF101014),
    primaryContainer = Color(0xFF2B3350), onPrimaryContainer = OnBg,
    secondary = Accent, tertiary = Accent,
    background = Bg, onBackground = OnBg,
    surface = SurfaceC, onSurface = OnBg,
    surfaceVariant = Variant, onSurfaceVariant = Muted,
    outline = Muted.copy(alpha = 0.6f), outlineVariant = Variant,
    surfaceTint = Color.Transparent
)

@Composable
fun VideoTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        window.statusBarColor = Bg.toArgb()
        window.navigationBarColor = Bg.toArgb()
    }
    MaterialTheme(colorScheme = Scheme) {
        Surface(Modifier.fillMaxSize(), color = Bg, contentColor = OnBg, content = content)
    }
}
