package com.jullmood.video.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.jullmood.video.identify.Category
import com.jullmood.video.identify.Confidence
import com.jullmood.video.identify.ContentType
import com.jullmood.video.identify.IdSource
import com.jullmood.video.identify.IdentResult
import com.jullmood.video.identify.Identification
import com.jullmood.video.identify.Suggestion

/** Acceso a la base de datos. Todas las funciones son síncronas: llamarlas desde Dispatchers.IO. */
class VideoRepository(ctx: Context) {

    private val helper = VideoDb(ctx)

    /** Videos con progreso, favorito e identificación vigente (manual si existe, si no automática), ordenados por nombre. */
    fun all(): List<Video> {
        val out = ArrayList<Video>()
        val sql = """
            SELECT v.vkey, v.uri, v.name, v.folder, v.size, v.modified, v.duration_ms, v.width, v.height, v.added_at,
                   v.related,
                   COALESCE(p.position_ms, 0), COALESCE(p.watched, 0), p.updated_at,
                   CASE WHEN f.vkey IS NULL THEN 0 ELSE 1 END,
                   a.category, a.content_type, a.title, a.creator, a.season, a.episode, a.part, a.year,
                   a.confidence, a.evidence, a.suggestion, a.also_in, a.clean_name,
                   m.category, m.content_type, m.title, m.creator
            FROM video v
            LEFT JOIN progress p ON p.vkey = v.vkey
            LEFT JOIN favorite f ON f.vkey = v.vkey
            LEFT JOIN identity_auto a ON a.vkey = v.vkey
            LEFT JOIN override_manual m ON m.vkey = v.vkey
            ORDER BY v.name COLLATE NOCASE
        """.trimIndent()
        helper.readableDatabase.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) {
                out += Video(
                    key = c.getString(0), uri = c.getString(1), name = c.getString(2), folder = c.getString(3),
                    sizeBytes = c.getLong(4), modifiedMs = c.getLong(5), durationMs = c.getLong(6),
                    width = c.getInt(7), height = c.getInt(8), addedAt = c.getLong(9),
                    related = c.getString(10) ?: "",
                    positionMs = c.getLong(11), watched = c.getInt(12) == 1,
                    lastPlayedAt = if (c.isNull(13)) 0L else c.getLong(13),
                    favorite = c.getInt(14) == 1,
                    identity = readIdentity(c)
                )
            }
        }
        return out
    }

    private fun str(c: Cursor, i: Int): String = if (c.isNull(i)) "" else c.getString(i) ?: ""

    /** Construye la identificación de una fila de [all]. La corrección manual gana siempre sobre la automática. */
    private fun readIdentity(c: Cursor): Identification {
        val hasAuto = !c.isNull(15)
        val hasManual = !c.isNull(28)
        val also = str(c, 26).split(',').filter { it.isNotEmpty() }.map { Category.fromName(it) }
            .filter { it != Category.SIN_CLASIFICAR }
        val auto: Identification? = if (hasAuto) {
            val conf = c.getFloat(23)
            Identification(
                category = Category.fromName(c.getString(15)),
                contentType = ContentType.fromName(str(c, 16)),
                title = str(c, 17), creator = str(c, 18),
                season = c.getInt(19), episode = c.getInt(20), part = c.getInt(21), year = c.getInt(22),
                cleanName = str(c, 27),
                confidence = conf, level = Confidence.of(conf), source = IdSource.AUTO,
                evidence = str(c, 24).split('\n').filter { it.isNotEmpty() },
                suggestion = Suggestion.decode(str(c, 25)),
                also = also
            )
        } else null
        if (hasManual) {
            return Identification(
                category = Category.fromName(c.getString(28)),
                contentType = ContentType.fromName(str(c, 29)),
                title = str(c, 30), creator = str(c, 31),
                season = auto?.season ?: 0, episode = auto?.episode ?: 0, part = auto?.part ?: 0, year = auto?.year ?: 0,
                cleanName = auto?.cleanName ?: "",
                confidence = 1f, level = Confidence.HIGH, source = IdSource.MANUAL,
                evidence = listOf("Corrección manual"),
                suggestion = null, also = emptyList()
            )
        }
        return auto ?: Identification.NONE
    }

    /**
     * Sincroniza el índice `video` con el resultado de un escaneo: inserta lo nuevo, actualiza lo existente
     * y elimina lo que ya no está. NO toca progress, favorite ni ningún dato del usuario.
     * Todo en una transacción: si algo falla, el índice queda como estaba.
     */
    fun applyScan(found: List<Video>, now: Long) {
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val existing = HashSet<String>()
            db.rawQuery("SELECT vkey FROM video", null).use { c -> while (c.moveToNext()) existing += c.getString(0) }
            val seen = HashSet<String>(found.size * 2)
            for (v in found) {
                seen += v.key
                val cv = ContentValues().apply {
                    put("uri", v.uri); put("name", v.name); put("folder", v.folder)
                    put("size", v.sizeBytes); put("modified", v.modifiedMs)
                    put("duration_ms", v.durationMs); put("width", v.width); put("height", v.height)
                    put("related", v.related)
                }
                if (v.key in existing) {
                    db.update("video", cv, "vkey = ?", arrayOf(v.key))
                } else {
                    cv.put("vkey", v.key)
                    // Fecha de "añadido": la del archivo si existe (así la primera pasada no pone todo igual).
                    cv.put("added_at", if (v.modifiedMs > 0) v.modifiedMs else now)
                    db.insert("video", null, cv)
                }
            }
            for (k in existing) if (k !in seen) {
                db.delete("video", "vkey = ?", arrayOf(k))
                // La identificación automática es recalculable: se purga. override_manual, progress y favorite NO se tocan.
                db.delete("identity_auto", "vkey = ?", arrayOf(k))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Guarda la posición; se marca como visto al llegar al 90 %. */
    fun saveProgress(key: String, positionMs: Long, durationMs: Long) {
        val watched = durationMs > 0 && positionMs >= durationMs * 9 / 10
        val cv = ContentValues().apply {
            put("vkey", key); put("position_ms", positionMs); put("duration_ms", durationMs)
            put("updated_at", System.currentTimeMillis()); put("watched", if (watched) 1 else 0)
        }
        helper.writableDatabase.insertWithOnConflict("progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun setFavorite(key: String, favorite: Boolean) {
        val db = helper.writableDatabase
        if (favorite) {
            val cv = ContentValues().apply { put("vkey", key); put("added_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("favorite", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        } else {
            db.delete("favorite", "vkey = ?", arrayOf(key))
        }
    }

    // ---------- Identificación ----------

    /** Huellas guardadas por vkey; el motor solo recalcula los videos cuya huella cambió. */
    fun identityFingerprints(): Map<String, String> {
        val out = HashMap<String, String>()
        helper.readableDatabase.rawQuery("SELECT vkey, fingerprint FROM identity_auto", null).use { c ->
            while (c.moveToNext()) out[c.getString(0)] = c.getString(1) ?: ""
        }
        return out
    }

    /** Guarda resultados automáticos en una sola transacción. Nunca toca override_manual. */
    fun saveAutoIdentities(results: List<IdentResult>) {
        if (results.isEmpty()) return
        val db = helper.writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            for (r in results) {
                val id = r.identification
                val cv = ContentValues().apply {
                    put("vkey", r.key)
                    put("category", id.category.name)
                    put("confidence", id.confidence.toDouble())
                    put("evidence", id.evidence.joinToString("\n"))
                    put("computed_at", now)
                    put("content_type", id.contentType.name)
                    put("title", id.title); put("creator", id.creator)
                    put("season", id.season); put("episode", id.episode); put("part", id.part); put("year", id.year)
                    put("suggestion", id.suggestion?.encode() ?: "")
                    put("also_in", id.also.joinToString(",") { it.name })
                    put("clean_name", id.cleanName)
                    put("fingerprint", r.fingerprint)
                }
                db.insertWithOnConflict("identity_auto", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Creadores que el usuario ha escrito en correcciones manuales (alimentan el registro de creadores del motor). */
    fun userCreators(): List<String> {
        val out = ArrayList<String>()
        helper.readableDatabase.rawQuery(
            "SELECT DISTINCT creator FROM override_manual WHERE creator <> ''", null
        ).use { c -> while (c.moveToNext()) out += c.getString(0) }
        return out
    }

    /** Corrección manual: persiste por vkey y tiene prioridad sobre el resultado automático. */
    fun setManual(key: String, category: Category, type: ContentType, title: String, creator: String) {
        val cv = ContentValues().apply {
            put("vkey", key); put("category", category.name); put("content_type", type.name)
            put("title", title.trim()); put("creator", creator.trim())
            put("updated_at", System.currentTimeMillis())
        }
        helper.writableDatabase.insertWithOnConflict("override_manual", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun clearManual(key: String) {
        helper.writableDatabase.delete("override_manual", "vkey = ?", arrayOf(key))
    }
}
