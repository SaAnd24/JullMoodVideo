package com.jullmood.video.identify

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas JVM del motor (sin Android). Se ejecutan con `gradle testDebugUnitTest`. */
class IdentificationEngineTest {

    private val engine = IdentificationEngine()

    private fun id(name: String, folder: String = "", w: Int = 1920, h: Int = 1080, durMin: Int = 20, related: Set<String> = emptySet(), siblings: Int = 0) =
        engine.identify(
            VideoFacts(name = name, folder = folder, sizeBytes = 500_000_000L, durationMs = durMin * 60_000L, width = w, height = h, related = related),
            IdentifyContext(siblingEpisodes = siblings)
        )

    @Test fun gameplayWithPart() {
        val r = id("Resident.Evil.4.Remake.Gameplay.Part.03.1080p.mkv")
        assertEquals(Category.VIDEOJUEGOS, r.category)
        assertEquals(ContentType.GAMEPLAY, r.contentType)
        assertEquals(3, r.part)
        assertTrue(r.title.startsWith("Resident Evil 4"))
        assertTrue(r.confidence >= 0.85f)
        assertTrue(r.evidence.isNotEmpty())
    }

    @Test fun creatorGameplay() {
        val r = id("Markiplier Resident Evil 7 Gameplay.mp4")
        assertEquals(Category.VIDEOJUEGOS, r.category)
        assertEquals("Markiplier", r.creator)
    }

    @Test fun movieWithYear() {
        val r = id("Resident.Evil.Afterlife.2010.1080p.mkv", durMin = 97)
        assertEquals(Category.PELICULAS, r.category)
        assertEquals(2010, r.year)
    }

    @Test fun episodeMarker() {
        val r = id("S02E04.mp4", durMin = 45)
        assertEquals(Category.SERIES, r.category)
        assertEquals(2, r.season)
        assertEquals(4, r.episode)
    }

    @Test fun unknownNamesStayUnclassified() {
        for (n in listOf("movie.mp4", "video_839271.mp4", "VID_20240513_2214.mp4")) {
            assertEquals(n, Category.SIN_CLASIFICAR, id(n).category)
        }
    }

    @Test fun abbreviationAloneDoesNotClassifyButSuggests() {
        val r = id("re4_final_part_2.mp4")
        assertEquals(Category.SIN_CLASIFICAR, r.category)
        assertNotNull(r.suggestion)
    }

    @Test fun folderGivesContext() {
        assertEquals(Category.VIDEOJUEGOS, id("re4_final_part_2.mp4", "Games/Resident Evil 4").category)
        assertEquals(Category.SIN_CLASIFICAR, id("re4_final_part_2.mp4", "Movies").category)
        assertEquals(Category.SIN_CLASIFICAR, id("re4_final_part_2.mp4", "Peliculas").category)
    }

    @Test fun seriesFromFolders() {
        val r = id("S02E04.mp4", "Series/Breaking Bad/Season 2", durMin = 45)
        assertEquals(Category.SERIES, r.category)
        assertEquals("Breaking Bad", r.title)
    }

    @Test fun typoStillMatches() {
        assertEquals(Category.VIDEOJUEGOS, id("Resident Evil 4 Gamplay Part 2.mp4").category)
    }

    @Test fun shortFormatNeedsVerticalShape() {
        val vertical = id("839271645.mp4", w = 1080, h = 1920, durMin = 0)
        val horizontal = id("839271645.mp4", w = 1920, h = 1080, durMin = 20)
        assertEquals(Category.SHORTS, vertical.category)
        assertEquals(Category.SIN_CLASIFICAR, horizontal.category)
    }

    @Test fun minimumConfidenceRule() {
        val r = id("video_839271.mp4")
        assertFalse(r.classified)
        assertTrue(r.confidence < Identification.MIN_CONFIDENCE)
    }

    @Test fun fingerprintIsStableAndSensitive() {
        val a = VideoFacts("a.mp4", "f", 10, 1000, 1920, 1080)
        val ctx = IdentifyContext.EMPTY
        assertEquals(engine.fingerprint(a, ctx), engine.fingerprint(a.copy(), ctx))
        assertNotEquals(engine.fingerprint(a, ctx), engine.fingerprint(a.copy(name = "b.mp4"), ctx))
        assertNotEquals(engine.fingerprint(a, ctx), IdentificationEngine(CreatorRegistry.of(listOf("Lolito"))).fingerprint(a, ctx))
    }

    @Test fun incrementalRunSkipsUnchanged() {
        val items = listOf("k1" to VideoFacts("Resident Evil 4 Gameplay.mp4", ""), "k2" to VideoFacts("movie.mp4", ""))
        val first = IdentifyBatch.run(items, emptyMap(), engine)
        assertEquals(2, first.size)
        val stored = first.associate { it.key to it.fingerprint }
        assertTrue(IdentifyBatch.run(items, stored, engine).isEmpty())
    }

    @Test fun virtualCollectionsAreViewsOfOneVideo() {
        val r = id("Markiplier Resident Evil 7 Gameplay.mp4")
        val ids = r.collections().map { it.id }
        assertTrue("cat:VIDEOJUEGOS" in ids)
        assertTrue("type:VIDEOJUEGOS:GAMEPLAY" in ids)
        assertTrue(ids.any { it.startsWith("creator:") })
    }
}
